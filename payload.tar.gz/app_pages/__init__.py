"""Focused QSMS application pages."""
