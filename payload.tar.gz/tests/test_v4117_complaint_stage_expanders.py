from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_v4117_release_continuity_and_v4118_build():
    assert (ROOT / "VERSION").read_text().strip() in {"4.11.7", "4.11.8","4.12.0", "4.12.1", "4.12.2", "4.12.3", "4.12.4", "4.12.5", "4.12.6", "4.12.7", "4.12.8", "4.12.9", "4.13.0", "4.13.1", "4.13.2", "4.13.3", "4.13.4", "4.13.5", "4.13.6", "4.13.7", "4.13.8", "4.13.9", "4.14.0", "4.14.2", "4.14.3", "4.14.4", "4.14.5", "4.14.6", "4.14.7", "4.14.8", "4.14.9", "4.14.10", "4.14.11", "4.14.12", "4.14.13", "4.14.14", "4.14.15", "4.14.16", "4.14.17", "4.14.18", "4.14.19", "4.14.20", "4.14.21", "4.14.22", "4.14.23", "4.14.24", "4.14.25", "4.14.26", "4.14.27", "4.14.28", "4.14.29", "4.14.30", "4.14.31", "4.14.32", "4.14.33", '4.14.34', '4.14.35', '4.14.36', '4.14.37', '4.14.38', '4.14.39', '4.14.40', '4.14.41', '4.14.42', '4.14.43', '4.14.44', '4.14.45'}
    ui = (ROOT / "core/ui.py").read_text()
    auth = (ROOT / "core/auth.py").read_text()
    assert "4118-GLOBAL-STAGED-SECTIONS" in ui
    assert "4118-GLOBAL-STAGED-SECTIONS" in auth


def test_complaint_entry_has_a_to_g_collapsed_stage_sequence():
    text = (ROOT / "app_pages/complaints.py").read_text()
    expected = (
        ("A", "COMPLAINT DETAILS"),
        ("B", "RESPONSIBILITY"),
        ("C", "PHOTOGRAPHS & MULTIPLE ATTACHMENTS"),
        ("D", "CONTAINMENT / ROOT CAUSE / CORRECTIVE ACTION"),
        ("E", "DEBIT NOTE / COMMERCIAL SETTLEMENT"),
        ("F", "COMPLAINT FOLLOW-UP & CLOSURE TRACKING"),
        ("H", "PRINT / DELETE"),
    )
    for stage, label in expected:
        assert f'stage_section("{stage}", "{label}"' in text


def test_global_stage_heading_is_100_percent_larger_bold_and_collapsed():
    ui = (ROOT / "core/ui.py").read_text()
    assert 'with st.expander(f"{letter} - {title}", expanded=False)' in ui
    assert "font-size:26px!important" in ui
    assert "font-weight:900!important" in ui
    assert "min-height:64px!important" in ui
