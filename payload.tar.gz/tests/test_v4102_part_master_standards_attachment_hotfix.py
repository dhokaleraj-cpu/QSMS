from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_part_master_imports_part_label():
    text = (ROOT / "app_pages" / "part_master.py").read_text()
    assert "part_label" in text.split("from core.selection_labels import", 1)[1].split("\n", 1)[0]
    assert "part_label(row)" in text


def test_standards_bank_has_first_save_attachment_uploader():
    text = (ROOT / "app_pages" / "standards_bank.py").read_text()
    assert "Upload Standard / Specification File" in text
    assert "new_standard_attachment" in text
    assert 'entity_type="CUSTOMER_STANDARD"' in text
    assert "render_attachment_manager" in text


def test_patch_version():
    assert (ROOT / "VERSION").read_text().strip() in {"4.10.2", "4.10.3", "4.10.5", "4.10.6", "4.10.7", "4.10.8", "4.10.9", "4.11.0", "4.11.1", "4.11.2", "4.11.3", "4.11.4", "4.11.5", "4.11.6", "4.11.7", "4.11.8","4.12.0", "4.12.1", "4.12.2", "4.12.3", "4.12.4", "4.12.5", "4.12.6", "4.12.7", "4.12.8", "4.12.9", "4.13.0", "4.13.1", "4.13.2", "4.13.3", "4.13.4", "4.13.5", "4.13.6", "4.13.7", "4.13.8", "4.13.9", "4.14.0", "4.14.2", "4.14.3", "4.14.4", "4.14.5", "4.14.6", "4.14.7", "4.14.8", "4.14.9", "4.14.10", "4.14.11", "4.14.12", "4.14.13", "4.14.14", "4.14.15", "4.14.16", "4.14.17", "4.14.18", "4.14.19", "4.14.20", "4.14.21", "4.14.22", "4.14.23", "4.14.24", "4.14.25", "4.14.26", "4.14.27", "4.14.28", "4.14.29", "4.14.30", "4.14.31", "4.14.32", "4.14.33", '4.14.34', '4.14.35', '4.14.36', '4.14.37', '4.14.38', '4.14.39', '4.14.40', '4.14.41', '4.14.42', '4.14.43', '4.14.44', '4.14.45'}
