from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def test_v484_version_and_migration():
    assert (ROOT/'VERSION').read_text().strip() in {'4.8.4','4.8.5','4.8.6','4.8.7','4.8.8','4.9.0','4.9.1','4.9.2','4.9.3','4.9.4','4.9.5','4.9.6','4.9.7','4.9.8', '4.9.9','4.10.0','4.10.1','4.10.2','4.10.3','4.10.5','4.10.6','4.10.7','4.10.8','4.10.9','4.11.0','4.11.1','4.11.2','4.11.3','4.11.4','4.11.5','4.11.6','4.11.7','4.11.8','4.12.0','4.12.1','4.12.2','4.12.3','4.12.4','4.12.5','4.12.6','4.12.7','4.12.8','4.12.9','4.13.0','4.13.1','4.13.2','4.13.3','4.13.4','4.13.5', '4.13.6','4.13.7','4.13.8','4.13.9','4.14.0','4.14.2','4.14.3', '4.14.4','4.14.5','4.14.6','4.14.7','4.14.8','4.14.9','4.14.10','4.14.11','4.14.12', '4.14.13', '4.14.14','4.14.15', '4.14.16','4.14.17','4.14.18','4.14.19','4.14.20', '4.14.21','4.14.22','4.14.23','4.14.24','4.14.25','4.14.26','4.14.27','4.14.28','4.14.29','4.14.30','4.14.31','4.14.32','4.14.33', '4.14.34', '4.14.35', '4.14.36', '4.14.37', '4.14.38', '4.14.39', '4.14.40', '4.14.41', '4.14.42', '4.14.43', '4.14.44', '4.14.45'}
    sql=(ROOT/'supabase/migrations/20260802193000_qsms_unified_records_v484.sql').read_text()
    for token in ['v_qsms_inward_register','supplier_name','part_number','dimensional_report_disposition','metlab_report_disposition']:
        assert token in sql

def test_unified_records_page_and_route():
    page=(ROOT/'app_pages/records_center.py').read_text()
    app=(ROOT/'streamlit_app.py').read_text()
    for token in ['Records Centre','Material Inward','Dimensional','MetLAB','Layouts','Masters']:
        assert token in page
    assert 'records-center' in app
    assert 'st.columns(13' in app

def test_dashboard_and_inward_share_register():
    dashboard=(ROOT/'app_pages/dashboard.py').read_text()
    service=(ROOT/'core/inward_service.py').read_text()
    inward=(ROOT/'app_pages/material_inward.py').read_text()
    assert 'v_qsms_inward_register' in dashboard
    assert 'v_qsms_inward_register' in service
    assert 'CURRENT MATERIAL INWARD STATUS' in inward
    assert 'supplier_name' in inward and 'part_number' in inward

def test_same_heat_new_rmtc_action():
    page=(ROOT/'app_pages/rmtc_pages.py').read_text()
    for token in ['Add New RMTC for This Heat Number','_start_new_rmtc_for_heat','rmtc_new_form_nonce']:
        assert token in page
