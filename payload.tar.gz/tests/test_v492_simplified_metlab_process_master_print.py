from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_version_and_release_files():
    assert (ROOT / "VERSION").read_text().strip() in {"4.9.2", "4.9.3", "4.9.4", "4.9.5", "4.9.6", "4.9.7", "4.9.8", "4.9.9", "4.10.0", "4.10.1", "4.10.2", "4.10.3", "4.10.5", "4.10.6", "4.10.7", "4.10.8", "4.10.9", "4.11.0", "4.11.1", "4.11.2", "4.11.3", "4.11.4", "4.11.5", "4.11.6", "4.11.7", "4.11.8","4.12.0", "4.12.1", "4.12.2", "4.12.3", "4.12.4", "4.12.5", "4.12.6", "4.12.7", "4.12.8", "4.12.9", "4.13.0", "4.13.1", "4.13.2", "4.13.3", "4.13.4", "4.13.5", "4.13.6", "4.13.7", "4.13.8", "4.13.9", "4.14.0", "4.14.2", "4.14.3", "4.14.4", "4.14.5", "4.14.6", "4.14.7", "4.14.8", "4.14.9", "4.14.10", "4.14.11", "4.14.12", "4.14.13", "4.14.14", "4.14.15", "4.14.16", "4.14.17", "4.14.18", "4.14.19", "4.14.20", "4.14.21", "4.14.22", "4.14.23", "4.14.24", "4.14.25", "4.14.26", "4.14.27", "4.14.28", "4.14.29", "4.14.30", "4.14.31", "4.14.32", "4.14.33", '4.14.34', '4.14.35', '4.14.36', '4.14.37', '4.14.38', '4.14.39', '4.14.40', '4.14.41', '4.14.42', '4.14.43', '4.14.44', '4.14.45'}
    assert (ROOT / "docs/RELEASE_4_9_2.md").exists()
    assert (ROOT / "supabase/migrations/20260805194500_qsms_simplified_metlab_process_master_print_v492.sql").exists()


def test_part_master_has_only_approved_metlab_requirement_sections():
    page = (ROOT / "app_pages/part_master.py").read_text()
    assert "OSP INSPECTION FOR METLAB" in page
    assert "METALLURGICAL REQUIREMENTS" in page
    assert "HEAT TREATMENT DETAILS" not in page
    assert "OSP PROCESS & INWARD SPECIFICATIONS" not in page
    assert page.count('"Parameter"') >= 2
    assert page.count('"Minimum Specification"') >= 2
    assert page.count('"Maximum Specification"') >= 2


def test_process_master_is_dedicated_and_not_duplicated():
    app = (ROOT / "streamlit_app.py").read_text()
    process = (ROOT / "app_pages/process_master.py").read_text()
    reference = (ROOT / "app_pages/reference_master.py").read_text()
    assert '"process-entry"' in app and '"process-records"' in app
    assert "Process Code" in process and "Process Type" in process
    reference_keys = reference.split("REFERENCE_KEYS", 1)[1].split(")", 1)[0]
    assert '"processes"' not in reference_keys


def test_requirement_schema_and_generated_layouts():
    migration = (ROOT / "supabase/migrations/20260805194500_qsms_simplified_metlab_process_master_print_v492.sql").read_text()
    for token in (
        "part_metallurgical_requirements",
        "minimum_spec",
        "maximum_spec",
        "OSP_METLAB",
        "FINAL_METALLURGICAL",
        "qsms_generate_final_metallurgical_layout",
        "v_qsms_osp_metlab_requirements",
        "v_qsms_part_metallurgical_requirements",
    ):
        assert token in migration


def test_osp_queue_skips_non_required_inspection_types():
    service = (ROOT / "core/osp_service.py").read_text()
    assert 'requirement_flag = "dimensional_required" if report_type == "DIMENSIONAL" else "metlab_required"' in service
    # Later controlled releases keep the flag gate but also accept an APPROVED OSP layout
    # as authoritative evidence, so legacy flags cannot hide a valid inspection queue.
    assert "required_by_flag = bool(row.get(requirement_flag))" in service
    assert "required_by_approved_layout" in service
    assert "if not (required_by_flag or required_by_approved_layout)" in service


def test_single_navigation_and_export_shipment_theme():
    ui = (ROOT / "core/ui.py").read_text()
    app = (ROOT / "streamlit_app.py").read_text()
    suppressed = ui.split("def subpage_navigation", 1)[1].split("def module_submenu", 1)[0]
    assert "return None" in suppressed
    assert "linear-gradient(110deg,#082F5C" in ui
    assert "menu_active_{slug}" in app
    assert "MODULES" in app


def test_report_print_header_footer_and_excel_theme():
    reporting = (ROOT / "core/reporting.py").read_text()
    reports = (ROOT / "app_pages/reports.py").read_text()
    requirements = (ROOT / "requirements.txt").read_text()
    for token in ("FOUR STAR INDUSTRIES", "QUALITY CONTROL MONITORING SYSTEM", "Page {self._pageNumber} of {page_count}"):
        assert token in reporting
    assert "report_pdf_bytes" in reports
    assert "oddHeader" in reports and "oddFooter" in reports
    assert "reportlab" in requirements
