from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_v4132_release_and_visual_contract():
    assert (ROOT / "VERSION").read_text().strip() in {"4.13.2", "4.13.3", "4.13.4", "4.13.5", "4.13.6", "4.13.7", "4.13.8", "4.13.9", "4.14.0", "4.14.2", "4.14.3", "4.14.4", "4.14.5", "4.14.6", "4.14.7", "4.14.8", "4.14.9", "4.14.10", "4.14.11", "4.14.12", "4.14.13", "4.14.14", "4.14.15", "4.14.16", "4.14.17", "4.14.18", "4.14.19", "4.14.20", "4.14.21", "4.14.22", "4.14.23", "4.14.24", "4.14.25", "4.14.26", "4.14.27", "4.14.28", "4.14.29", "4.14.30", "4.14.31", "4.14.32", "4.14.33", '4.14.34', '4.14.35', '4.14.36', '4.14.37', '4.14.38', '4.14.39', '4.14.40', '4.14.41', '4.14.42', '4.14.43', '4.14.44', '4.14.45'}
    ui = (ROOT / "core" / "ui.py").read_text()
    auth = (ROOT / "core" / "auth.py").read_text()
    assert "4132-MERITOR-EXACT-GRID-SECTION-LOGIN-IMAGE" in ui
    assert "--qcms-portal-maroon:#B20738" in ui
    assert "--qcms-portal-field:#FFFDF0" in ui
    assert "Exact enterprise table/grid contract" in ui
    assert "details[data-testid=\"stExpander\"] summary p" in ui
    assert "login_factory.jpeg" in auth
    assert "qcms_login_image_card" in auth
    assert 'st.columns([1.85, 1.0]' in auth
    assert (ROOT / "assets" / "login_factory.jpeg").exists()
