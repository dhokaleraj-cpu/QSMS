from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_release_version_and_migration():
    assert (ROOT / "VERSION").read_text().strip() in {"4.12.1", "4.12.2", "4.12.3", "4.12.4", "4.12.5", "4.12.6", "4.12.7", "4.12.8", "4.12.9", "4.13.0", "4.13.1", "4.13.2", "4.13.3", "4.13.4", "4.13.5", "4.13.6", "4.13.7", "4.13.8", "4.13.9", "4.14.0", "4.14.2", "4.14.3", "4.14.4", "4.14.5", "4.14.6", "4.14.7", "4.14.8", "4.14.9", "4.14.10", "4.14.11", "4.14.12", "4.14.13", "4.14.14", "4.14.15", "4.14.16", "4.14.17", "4.14.18", "4.14.19", "4.14.20", "4.14.21", "4.14.22", "4.14.23", "4.14.24", "4.14.25", "4.14.26", "4.14.27", "4.14.28", "4.14.29", "4.14.30", "4.14.31", "4.14.32", "4.14.33", '4.14.34', '4.14.35', '4.14.36', '4.14.37', '4.14.38', '4.14.39', '4.14.40', '4.14.41', '4.14.42', '4.14.43', '4.14.44', '4.14.45'}
    migration = ROOT / "supabase/migrations/20260819170000_qcms_master_driven_standalone_reports_v4121.sql"
    assert migration.exists()
    sql = migration.read_text()
    for token in ("customer_id", "material_grade_id", "batch_number", "supplier_reference_number", "supply_condition", "reference_text", "qcms_fill_report_part_master_context"):
        assert token in sql


def test_standalone_reports_are_master_driven_and_auto_layout():
    met = (ROOT / "app_pages/metlab_report.py").read_text()
    dim = (ROOT / "app_pages/dimensional_report.py").read_text()
    service = (ROOT / "core/inspection_service.py").read_text()
    for source in (met, dim):
        for token in ("Customer", "Material Grade", "Batch Number", "Supplier Invoice / Reference", "OSP Process", "Process Specification"):
            assert token in source
    assert "Auto Layout from Part Master" in dim
    assert "Raw Material Inward MetLAB Layout · Layout Master" in met
    assert "Part Master Final Metallurgical Requirements" in met
    for source in (met, dim):
        assert '"customer_id": part.get("customer_id")' in source
        assert '"material_grade_id": part.get("material_grade_id")' in source
    assert "def standalone_part_context" in service
    assert "def standalone_osp_process_groups" in service
    assert "def auto_standalone_plan" in service
    assert 'scope == "FINAL_DISPATCH_STAGE" and layout_type.upper() == "METLAB"' in service


def test_controlled_pdfs_include_lab_report_header_context():
    report = (ROOT / "core/reporting.py").read_text()
    for token in ("Customer", "Supplier / OSP Vendor", "Material Used", "Supplier Invoice / Reference", "Quantity (pcs)", "Heat Number", "Heat Code", "Supplier / HT / OSP Batch", "Internal / FSI Batch", "Drawing / Revision", "Sample / Reference"):
        assert token in report
    assert "FINAL METALLURGICAL TEST REPORT" in report
    assert "RAW MATERIAL DIMENSIONAL INSPECTION REPORT" in report


def test_supplier_and_internal_batch_are_distinct_in_standalone_reports():
    for rel in ("app_pages/metlab_report.py", "app_pages/dimensional_report.py"):
        text = (ROOT / rel).read_text()
        assert "Supplier / HT / OSP Batch Number" in text
        assert "Internal / FSI Batch Number" in text
        assert '"vendor_batch_number_snapshot": vendor_batch_number.strip() or None' in text
    reporting = (ROOT / "core/reporting.py").read_text()
    assert "Supplier / HT / OSP Batch" in reporting
    assert "Internal / FSI Batch" in reporting
