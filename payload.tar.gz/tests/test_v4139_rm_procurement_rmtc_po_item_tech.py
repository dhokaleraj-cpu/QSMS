from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def text(path): return (ROOT/path).read_text(encoding='utf-8')

def test_customer_purchase_order_keeps_saved_rm_procurement_visibility():
    s=text('core/supply_chain_service.py')
    assert "must respect the decision saved with" in s
    assert 'def pending_customer_orders_for_rm' in s
    assert 'def create_purchase_order' in s
    if (ROOT / "VERSION").read_text().strip() == "4.14.0":
        token='proposed_three_month_qty=number(order.get("order_qty_pcs")) if str(order.get("order_type") or "") == "PURCHASE_ORDER" else 0.0'
        assert s.count(token) >= 1
    else:
        assert "saved RM procurement decision" in s
        assert "current system stock is sufficient for the rolling three-month schedule" not in s

def test_incremental_approved_rmtc_part_guard_allows_pending_part():
    sql=text('supabase/migrations/20260822224500_qcms_rmtc_incremental_part_release_guard_v4139.sql')
    assert "v_pending_decisions" in sql
    assert "new.status = 'PARTIALLY_APPROVED' and v_release_decisions <= 0" in sql
    assert "APPROVED RMTC status requires every covered Part Number" in sql
    assert "PARTIALLY_APPROVED permits released Parts together with newly pending/on-hold/rejected" in sql

def test_po_print_is_item_then_item_specific_technical_data():
    p=text('core/purchase_order_reporting.py')
    assert 'RAW MATERIAL / FORGING PARAMETERS & SUPPLIER TECHNICAL DATA' in p
    if (ROOT / "VERSION").read_text().strip() == "4.14.0":
        assert 'compact_technical_pairs' in p
        assert 'Item-wise technical pocket directly under the item line.' in p
        assert p.index('item_row_bottom = y - 29') < p.index('compact_technical_pairs(item)')
    else:
        assert 'def _draw_technical' in p
        assert 'One complete item pocket on the first page' in p
        assert p.index('_draw_item_row') < p.index('_draw_technical')

def test_build_markers():
    markers=('4139-RM-PROCUREMENT-LINK-RMTC-PART-PO-ITEM-TECH','4140-PO-SOURCE-RMTC-VALIDATION-HSN-EMAIL')
    for f in ('core/ui.py','core/auth.py','streamlit_app.py'):
        assert any(marker in text(f) for marker in markers)
