from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_v487_version_release_and_attachment_migration():
    assert (ROOT / "VERSION").read_text().strip() in {"4.8.7", "4.8.8", "4.9.0", "4.9.1", "4.9.2", "4.9.3", "4.9.4", "4.9.5", "4.9.6", "4.9.7", "4.9.8", "4.9.9", "4.10.0", "4.10.1", "4.10.2", "4.10.3", "4.10.5", "4.10.6", "4.10.7", "4.10.8", "4.10.9", "4.11.0", "4.11.1", "4.11.2", "4.11.3", "4.11.4", "4.11.5", "4.11.6", "4.11.7", "4.11.8","4.12.0", "4.12.1", "4.12.2", "4.12.3", "4.12.4", "4.12.5", "4.12.6", "4.12.7", "4.12.8", "4.12.9", "4.13.0", "4.13.1", "4.13.2", "4.13.3", "4.13.4", "4.13.5", "4.13.6", "4.13.7", "4.13.8", "4.13.9", "4.14.0", "4.14.2", "4.14.3", "4.14.4", "4.14.5", "4.14.6", "4.14.7", "4.14.8", "4.14.9", "4.14.10", "4.14.11", "4.14.12", "4.14.13", "4.14.14", "4.14.15", "4.14.16", "4.14.17", "4.14.18", "4.14.19", "4.14.20", "4.14.21", "4.14.22", "4.14.23", "4.14.24", "4.14.25", "4.14.26", "4.14.27", "4.14.28", "4.14.29", "4.14.30", "4.14.31", "4.14.32", "4.14.33", '4.14.34', '4.14.35', '4.14.36', '4.14.37', '4.14.38', '4.14.39', '4.14.40', '4.14.41', '4.14.42', '4.14.43', '4.14.44', '4.14.45'}
    assert (ROOT / "docs/RELEASE_4_8_7.md").exists()
    sql = (ROOT / "supabase/migrations/20260803090000_qsms_optional_attachments_v487.sql").read_text()
    for token in [
        "qsms_delete_document_attachment",
        "RMTC_ENTRY",
        "MATERIAL_INWARD",
        "qsms_storage_delete",
        "authenticated QSMS session",
    ]:
        assert token in sql


def test_dashboard_removes_master_kpis_and_has_distinct_quick_action_colors():
    text = (ROOT / "app_pages/dashboard.py").read_text()
    for removed in ["Active Parts", '"Customers"', '"Suppliers"', "Steel Mills"]:
        assert removed not in text
    for color in ["#0F4C81", "#7C3AED", "#00897B", "#F59E0B", "#0284C7", "#16A34A", "#C026D3", "#475569"]:
        assert color in text
    ui = (ROOT / "core/ui.py").read_text()
    assert "linear-gradient(135deg" in ui
    assert "--dash-color" in ui


def test_every_top_level_module_has_a_submenu():
    app = (ROOT / "streamlit_app.py").read_text()
    for module in ["Dashboard", "Masters", "RMTC", "Inward", "Inspections", "Records", "Templates"]:
        assert f'"{module}": (' in app
    assert "module_submenu(current_module" in app
    ui = (ROOT / "core/ui.py").read_text()
    assert "def module_submenu" in ui
    assert "fsi_module_subnav" in ui


def test_rmtc_and_inward_support_three_optional_attachments():
    rmtc = (ROOT / "app_pages/rmtc_pages.py").read_text()
    inward = (ROOT / "app_pages/material_inward.py").read_text()
    for token in ["RMTC_COPY", "RMTC_ATTACHMENT_2", "RMTC_ATTACHMENT_3"]:
        assert token in rmtc
    for token in ["INWARD_COPY", "INWARD_ATTACHMENT_2", "INWARD_ATTACHMENT_3"]:
        assert token in inward
    assert "new_attachment_uploaders" in rmtc
    assert "render_attachment_manager" in rmtc
    assert "new_attachment_uploaders" in inward
    assert "render_attachment_manager" in inward


def test_attachment_manager_supports_download_password_replace_and_delete():
    text = (ROOT / "core/attachments.py").read_text()
    for token in [
        "st.download_button",
        "verify_current_password(password)",
        "Replace attachment",
        "Delete attachment",
        "All attachment slots are optional",
        "qsms_delete_document_attachment",
    ]:
        assert token in text


def test_attachment_register_has_module_specific_write_policies():
    sql = (ROOT / "supabase/migrations/20260803091000_qsms_attachment_module_permissions_v487.sql").read_text()
    for token in [
        "qsms_attachment_module",
        "qsms_can_manage_attachment",
        "tenant_insert on public.document_attachments",
        "tenant_update on public.document_attachments",
        "RMTC_ENTRY",
        "MATERIAL_INWARD",
    ]:
        assert token in sql


def test_cloud_dependencies_are_declared_directly():
    requirements = (ROOT / "requirements.txt").read_text().lower()
    assert "plotly" in requirements
    assert "httpx" in requirements
