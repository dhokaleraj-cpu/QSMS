from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_version_and_release_note():
    assert (ROOT / "VERSION").read_text().strip() in {"4.9.3", "4.9.4", "4.9.5", "4.9.6", "4.9.7", "4.9.8", "4.9.9", "4.10.0", "4.10.1", "4.10.2", "4.10.3", "4.10.5", "4.10.6", "4.10.7", "4.10.8", "4.10.9", "4.11.0", "4.11.1", "4.11.2", "4.11.3", "4.11.4", "4.11.5", "4.11.6", "4.11.7", "4.11.8","4.12.0", "4.12.1", "4.12.2", "4.12.3", "4.12.4", "4.12.5", "4.12.6", "4.12.7", "4.12.8", "4.12.9", "4.13.0", "4.13.1", "4.13.2", "4.13.3", "4.13.4", "4.13.5", "4.13.6", "4.13.7", "4.13.8", "4.13.9", "4.14.0", "4.14.2", "4.14.3", "4.14.4", "4.14.5", "4.14.6", "4.14.7", "4.14.8", "4.14.9", "4.14.10", "4.14.11", "4.14.12", "4.14.13", "4.14.14", "4.14.15", "4.14.16", "4.14.17", "4.14.18", "4.14.19", "4.14.20", "4.14.21", "4.14.22", "4.14.23", "4.14.24", "4.14.25", "4.14.26", "4.14.27", "4.14.28", "4.14.29", "4.14.30", "4.14.31", "4.14.32", "4.14.33", '4.14.34', '4.14.35', '4.14.36', '4.14.37', '4.14.38', '4.14.39', '4.14.40', '4.14.41', '4.14.42', '4.14.43', '4.14.44', '4.14.45'}
    assert (ROOT / "docs/RELEASE_4_9_3.md").exists()


def test_high_contrast_export_shipment_theme_is_streamlit_wrapper_safe():
    ui = (ROOT / "core" / "ui.py").read_text()
    for token in (
        '[class*="st-key-fsi_shell"] div[data-testid="stVerticalBlockBorderWrapper"]',
        'linear-gradient(110deg,#073462 0%,#073E78 46%,#0A68AC 100%)',
        '[class*="st-key-fsi_top_nav"] div[data-testid="stVerticalBlockBorderWrapper"]',
        'background:#F3F8FC!important',
        '[class*="st-key-menu_active_"]',
        '.stApp [data-stale="true"]{opacity:1!important;}',
        '--erp-font:Aptos',
    ):
        assert token in ui


def test_streamlit_theme_matches_export_shipment_background():
    config = (ROOT / ".streamlit" / "config.toml").read_text()
    assert any(token in config for token in ('primaryColor = "#315F79"', 'primaryColor = "#1884D8"', 'primaryColor = "#0A68AC"'))
    assert 'backgroundColor = "#F1F3F5"' in config or 'backgroundColor = "#F8FBFE"' in config or 'backgroundColor = "#EFEFEF"' in config
    assert 'textColor = "#1E2A33"' in config or 'textColor = "#121820"' in config or 'textColor = "#343434"' in config
