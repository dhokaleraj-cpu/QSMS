from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_version_4103():
    assert (ROOT / "VERSION").read_text().strip() in {"4.10.3", "4.10.5", "4.10.6", "4.10.7", "4.10.8", "4.10.9", "4.11.0", "4.11.1", "4.11.2", "4.11.3", "4.11.4", "4.11.5", "4.11.6", "4.11.7", "4.11.8","4.12.0", "4.12.1", "4.12.2", "4.12.3", "4.12.4", "4.12.5", "4.12.6", "4.12.7", "4.12.8", "4.12.9", "4.13.0", "4.13.1", "4.13.2", "4.13.3", "4.13.4", "4.13.5", "4.13.6", "4.13.7", "4.13.8", "4.13.9", "4.14.0", "4.14.2", "4.14.3", "4.14.4", "4.14.5", "4.14.6", "4.14.7", "4.14.8", "4.14.9", "4.14.10", "4.14.11", "4.14.12", "4.14.13", "4.14.14", "4.14.15", "4.14.16", "4.14.17", "4.14.18", "4.14.19", "4.14.20", "4.14.21", "4.14.22", "4.14.23", "4.14.24", "4.14.25", "4.14.26", "4.14.27", "4.14.28", "4.14.29", "4.14.30", "4.14.31", "4.14.32", "4.14.33", '4.14.34', '4.14.35', '4.14.36', '4.14.37', '4.14.38', '4.14.39', '4.14.40', '4.14.41', '4.14.42', '4.14.43', '4.14.44', '4.14.45'}


def test_part_standard_download_shows_required_details_and_admin_unlink():
    text = (ROOT / "app_pages" / "part_master.py").read_text()
    assert "standard_name_text" in text
    assert "author_text" in text
    assert "process_text" in text
    assert "ADMIN APPROVAL — Unlink Standard from Part" in text
    assert "is_admin(current_profile())" in text
    assert 'table="part_standard_links"' in text
    assert "Add Selected Standards" in text
    # ordinary linking must no longer delete links as a side effect of multiselect save
    link_block = text.split("part_master_render_entry_d", 1)[1].split("part_master_render_entry_e", 1)[0]
    assert 'repo.delete("part_standard_links"' not in link_block


def test_database_enforces_admin_only_unlink():
    text = (ROOT / "supabase" / "migrations" / "20260812184500_qcms_admin_standard_unlink_readability_v4103.sql").read_text()
    assert "qcms_admin_only_part_standard_unlink" in text
    assert "current_app_role()='ADMIN'" in text
    assert "before delete on public.part_standard_links" in text


def test_readability_layer_is_present():
    text = (ROOT / "core" / "ui.py").read_text()
    assert "readability" in text
    assert "font-weight:450!important" in text
    assert "font-weight:880!important" in text
    assert "font-weight:900!important" in text
