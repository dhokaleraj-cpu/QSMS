from __future__ import annotations

import hashlib
import re
from difflib import SequenceMatcher
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

import pandas as pd

from core.database import get_session_client
from core.attachments import AttachmentService
from core.dimensional_import import parse_dimensional_workbook_bytes
from core.inspection_queue import build_inspection_queue, pending_rows
from core.repository import Repository
from core.inspection_layout_metadata import BEND_TEST, GENERAL_METLAB, inspection_method_from_rows, row_metadata
from core.record_audit import annotate_transaction_rows

FINAL_DISPOSITIONS = ("ON_HOLD", "ACCEPTED", "ACCEPTED_UNDER_RESERVE", "REJECTED")
RESULT_OPTIONS = ("PASS", "FAIL", "NOT_EVALUATED", "NOT_APPLICABLE")


def _text(value: Any) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    return str(value).strip()


def _number(value: Any) -> float | None:
    if value is None or value == "" or (isinstance(value, float) and pd.isna(value)):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None




def _layout_token(value: Any, fallback: str, max_length: int = 36) -> str:
    text = re.sub(r"[^A-Za-z0-9]+", "-", _text(value).upper()).strip("-")
    return (text or fallback)[:max_length].strip("-") or fallback

def _attribute_pass(value: Any) -> bool:
    text = _text(value).upper()
    if not text:
        return False
    accepted = ("OK", "PASS", "ACCEPTED", "FOUND OK", "YES", "CONFORM", "SATISFACTORY", "FOR REF")
    return any(token in text for token in accepted)


class InspectionService:
    def __init__(self) -> None:
        self.repo = Repository()

    def parts(self) -> list[dict]:
        return self.repo.select("parts", eq={"status": "ACTIVE"}, order_by="part_number", limit=3000)

    def processes(self) -> list[dict]:
        return self.repo.select("processes", eq={"status": "ACTIVE"}, order_by="process_name", limit=1000)

    def stages(self) -> list[dict]:
        return self.repo.select("inspection_stages", eq={"status": "ACTIVE"}, order_by="sequence_no", limit=1000)

    def parties(self) -> list[dict]:
        return self.repo.select("parties", eq={"status": "ACTIVE"}, order_by="party_name", limit=3000)

    def material_grades(self) -> list[dict]:
        return self.repo.select("material_grades", eq={"status": "ACTIVE"}, order_by="grade_code", limit=1000)

    def standalone_part_context(self, part_id: str) -> dict[str, Any]:
        """Master-driven header context for standalone quality reports."""
        part = self.repo.get("parts", part_id) or {}
        customer = self.repo.get("parties", str(part.get("customer_id") or "")) or {}
        grade = self.repo.get("material_grades", str(part.get("material_grade_id") or "")) or {}
        links = self.repo.select("part_supplier_links", eq={"part_id": part_id, "approved": True}, limit=1000)
        raw_rows = self.repo.select("part_raw_material_details", eq={"part_id": part_id, "status": "ACTIVE"}, order_by="sequence_no", limit=1000)
        supplier_ids: list[str] = []
        for row in [*links, *raw_rows]:
            value = str(row.get("supplier_id") or "")
            if value and value not in supplier_ids:
                supplier_ids.append(value)
        return {"part": part, "customer": customer, "material_grade": grade, "supplier_ids": supplier_ids, "raw_material_rows": raw_rows}

    def standalone_osp_process_groups(self, part_id: str, layout_type: str) -> list[dict]:
        flag = "metlab_required" if layout_type.upper() == "METLAB" else "dimensional_required"
        groups = self.repo.select(
            "part_process_specifications",
            eq={"part_id": part_id, "inward_type": "OSP_PROCESS", "status": "ACTIVE"},
            order_by="sequence_no", limit=1000,
        )
        output: list[dict] = []
        for row in groups:
            params = self.repo.select(
                "part_process_parameter_specifications",
                eq={"process_specification_id": str(row.get("id")), "inspection_type": layout_type.upper(), "status": "ACTIVE"},
                order_by="sequence_no", limit=5,
            )
            if bool(row.get(flag)) or params:
                output.append(row)
        return output

    def raw_material_metlab_plans(self, part_id: str, *, approved_only: bool = True) -> list[dict]:
        """Approved Layout Master plans eligible for Raw Material Inward MetLAB only.

        FINAL_METALLURGICAL plans generated from Part Master are intentionally excluded.
        """
        rows = self.plans("METLAB", part_id, approved_only=approved_only)
        return [
            row for row in rows
            if str(row.get("inward_type") or "MATERIAL_INWARD").upper() == "MATERIAL_INWARD"
            and str(row.get("requirement_scope") or "GENERAL").upper() != "FINAL_METALLURGICAL"
        ]

    def standalone_plans(self, layout_type: str, part_id: str, scope: str, process_id: str | None = None) -> list[dict]:
        """Return controlled approved layouts eligible for a standalone stage."""
        layout_type = layout_type.upper()
        candidates = self.plans(layout_type, part_id, approved_only=True)
        if scope == "OSP_STAGE":
            candidates = [
                row for row in candidates
                if str(row.get("process_id") or "") == str(process_id or "")
                and str(row.get("inward_type") or "") == "OSP_PROCESS"
            ]
        elif scope == "FINAL_DISPATCH_STAGE" and layout_type.upper() == "METLAB":
            final_rows = [row for row in candidates if str(row.get("requirement_scope") or "") == "FINAL_METALLURGICAL"]
            if final_rows:
                candidates = final_rows
            else:
                candidates = [row for row in candidates if str(row.get("inward_type") or "MATERIAL_INWARD") == "MATERIAL_INWARD"]
        else:
            if layout_type == "METLAB":
                general = self.raw_material_metlab_plans(part_id, approved_only=True)
            else:
                general = [
                    row for row in candidates
                    if str(row.get("inward_type") or "MATERIAL_INWARD") == "MATERIAL_INWARD"
                    and str(row.get("requirement_scope") or "GENERAL") != "FINAL_METALLURGICAL"
                ]
            if general:
                candidates = general
        def sort_key(row: dict) -> tuple[str, str, str]:
            return (str(row.get("effective_date") or ""), str(row.get("revision") or ""), str(row.get("updated_at") or ""))
        return sorted(candidates, key=sort_key, reverse=True)

    def auto_standalone_plan(self, layout_type: str, part_id: str, scope: str, process_id: str | None = None) -> dict | None:
        """Select the highest-ranked controlled approved layout for a standalone stage."""
        candidates = self.standalone_plans(layout_type, part_id, scope, process_id)
        return candidates[0] if candidates else None

    def employees(self, authority: str | None = None) -> list[dict]:
        rows = self.repo.select("employees", eq={"status": "ACTIVE"}, order_by="first_name", limit=3000)
        if authority:
            filtered = [row for row in rows if authority in (row.get("approval_authorities") or [])]
            return filtered or rows
        return rows

    def inward_lots(self) -> list[dict]:
        rows = self.repo.select("inward_lots", order_by="created_at", desc=True, limit=4000)
        return [
            row for row in rows
            if str(row.get("receipt_disposition") or "") in ("ACCEPTED", "ACCEPTED_UNDER_RESERVE")
            and str(row.get("status") or "") != "REJECTED"
        ]

    def inspection_queue(self) -> list[dict]:
        return build_inspection_queue(
            self.inward_lots(),
            self.dimensional_reports(),
            self.metlab_reports(),
        )

    def pending_inward_lots(self, report_type: str) -> list[dict]:
        return pending_rows(self.inspection_queue(), report_type)

    def plans(
        self,
        layout_type: str | None = None,
        part_id: str | None = None,
        approved_only: bool = False,
        process_id: str | None = None,
        stage_id: str | None = None,
        inward_type: str | None = None,
    ) -> list[dict]:
        eq: dict[str, Any] = {}
        if layout_type:
            eq["layout_type"] = layout_type
        if part_id:
            eq["part_id"] = part_id
        if approved_only:
            eq["status"] = "APPROVED"
        if process_id:
            eq["process_id"] = process_id
        if stage_id:
            eq["inspection_stage_id"] = stage_id
        if inward_type:
            eq["inward_type"] = inward_type
        return self.repo.select("inspection_plans", eq=eq, order_by="plan_number", limit=3000)

    def ranked_plans(
        self,
        layout_type: str,
        part_id: str,
        process_id: str | None = None,
        stage_id: str | None = None,
        inward_type: str | None = None,
    ) -> list[dict]:
        """Return approved plans with exact part/process/stage match first."""
        plans = self.plans(layout_type, part_id, approved_only=True, inward_type=inward_type)

        def score(row: dict) -> tuple[int, str, str]:
            process_match = not process_id or str(row.get("process_id") or "") == str(process_id)
            stage_match = not stage_id or str(row.get("inspection_stage_id") or "") == str(stage_id)
            exact = int(process_match) + int(stage_match)
            effective = str(row.get("effective_date") or "")
            revision = str(row.get("revision") or "")
            return exact, effective, revision

        return sorted(plans, key=score, reverse=True)

    @staticmethod
    def auto_plan_number(part: Mapping[str, Any], process: Mapping[str, Any], stage: Mapping[str, Any], layout_name: str) -> str:
        """Controlled layout identity: Stage + Process + Part Number + Layout Name."""
        return "-".join((
            _layout_token(stage.get("stage_code") or stage.get("stage_name"), "STAGE", 20),
            _layout_token(process.get("process_code") or process.get("process_name"), "NOPROCESS", 24),
            _layout_token(part.get("part_number") or part.get("fsi_part_number"), "PART", 30),
            _layout_token(layout_name, "LAYOUT", 36),
        ))

    def scope_plan(self, payload: Mapping[str, Any], *, exclude_id: str | None = None) -> dict | None:
        """Return another current layout in the same controlled Part/Stage/Process scope."""
        part_id = str(payload.get("part_id") or "")
        if not part_id:
            return None
        rows = self.repo.select("inspection_plans", eq={"part_id": part_id}, order_by="updated_at", desc=True, limit=3000)
        wanted = (
            str(payload.get("process_id") or ""), str(payload.get("inspection_stage_id") or ""),
            str(payload.get("layout_type") or "DIMENSIONAL").upper(), str(payload.get("inward_type") or "MATERIAL_INWARD").upper(),
            str(payload.get("requirement_scope") or "GENERAL").upper(),
        )
        for row in rows:
            if exclude_id and str(row.get("id")) == str(exclude_id):
                continue
            if str(row.get("status") or "DRAFT").upper() not in {"DRAFT", "APPROVAL_PENDING", "APPROVED"}:
                continue
            scope = (
                str(row.get("process_id") or ""), str(row.get("inspection_stage_id") or ""),
                str(row.get("layout_type") or "DIMENSIONAL").upper(), str(row.get("inward_type") or "MATERIAL_INWARD").upper(),
                str(row.get("requirement_scope") or "GENERAL").upper(),
            )
            if scope == wanted:
                return row
        return None

    def get_plan(self, plan_id: str | None) -> dict | None:
        return self.repo.get("inspection_plans", plan_id)

    def plan_characteristics(self, plan_id: str) -> list[dict]:
        return self.repo.select(
            "inspection_plan_characteristics",
            eq={"inspection_plan_id": plan_id, "status": "ACTIVE"},
            order_by="sequence_no",
            limit=1000,
        )

    def plan_inspection_method(self, plan_id: str | None) -> str:
        if not plan_id:
            return GENERAL_METLAB
        plan = self.get_plan(plan_id) or {}
        rows = self.plan_characteristics(plan_id)
        return inspection_method_from_rows(
            rows,
            " ".join(str(plan.get(key) or "") for key in ("layout_name", "report_title", "source_template_name")),
        )

    def osp_parameter_characteristics(
        self,
        part_id: str,
        process_id: str,
        layout_type: str,
    ) -> tuple[dict | None, list[dict]]:
        """Return the active Part + OSP Process group and its layout-ready parameters."""
        groups = self.repo.select(
            "part_process_specifications",
            eq={
                "part_id": part_id,
                "process_id": process_id,
                "inward_type": "OSP_PROCESS",
                "status": "ACTIVE",
            },
            order_by="sequence_no",
            limit=20,
        )
        group = groups[0] if groups else None
        if not group:
            return None, []
        rows = self.repo.select(
            "part_process_parameter_specifications",
            eq={
                "process_specification_id": str(group["id"]),
                "inspection_type": layout_type,
                "status": "ACTIVE",
            },
            order_by="sequence_no",
            limit=1000,
        )
        characteristics = [
            {
                "sequence_no": row.get("sequence_no"),
                "characteristic_no": str(index),
                "characteristic": row.get("parameter_name"),
                "specification": row.get("specification_text"),
                "lower_spec": row.get("minimum_spec"),
                "upper_spec": row.get("maximum_spec"),
                "unit": row.get("unit"),
                "characteristic_type": "TEXT" if str(row.get("characteristic_type") or "NUMBER").upper() in {"TEXT", "ATTRIBUTE"} else "NUMBER",
                "checking_method": row.get("checking_method"),
                "checking_aid_text": row.get("checking_method"),
                "sample_size": row.get("sample_size") or group.get("sample_quantity") or 1,
                "is_mandatory": bool(row.get("is_mandatory", True)),
                "allow_na": bool(row.get("allow_na", False)),
                "report_section": layout_type,
                "status": row.get("status") or "ACTIVE",
                "layout_metadata": {
                    "source": "PART_MASTER_OSP_PROCESS_GROUP",
                    "process_specification_id": str(group["id"]),
                    "parameter_specification_id": str(row.get("id") or ""),
                    "drawing_number": group.get("drawing_number"),
                    "drawing_revision": group.get("drawing_revision"),
                },
            }
            for index, row in enumerate(rows, start=1)
        ]
        return group, characteristics

    def save_plan(self, payload: Mapping[str, Any], rows: Sequence[Mapping[str, Any]], plan_id: str | None = None) -> dict:
        controlled = dict(payload)
        part = self.repo.get("parts", str(controlled.get("part_id") or "")) or {}
        process = (self.repo.get("processes", str(controlled.get("process_id") or "")) or {}) if controlled.get("process_id") else {}
        stage = (self.repo.get("inspection_stages", str(controlled.get("inspection_stage_id") or "")) or {}) if controlled.get("inspection_stage_id") else {}
        controlled["plan_number"] = self.auto_plan_number(part, process, stage, str(controlled.get("layout_name") or ""))
        if str(controlled.get("requirement_scope") or "GENERAL").upper() != "FINAL_METALLURGICAL" and str(controlled.get("status") or "DRAFT").upper() in {"DRAFT", "APPROVAL_PENDING", "APPROVED"}:
            duplicate = self.scope_plan(controlled, exclude_id=plan_id)
            if duplicate:
                raise ValueError(
                    "Only one current inspection layout is allowed for the same Part + Inspection Stage + Process + Layout Type. "
                    f"Edit or supersede existing layout {duplicate.get('plan_number') or duplicate.get('layout_name') or duplicate.get('id')} instead of creating another one."
                )
        plan = self.repo.update("inspection_plans", plan_id, controlled) if plan_id else self.repo.insert("inspection_plans", controlled)
        pid = str(plan["id"])
        existing = {
            int(row.get("sequence_no") or 0): row
            for row in self.repo.select("inspection_plan_characteristics", eq={"inspection_plan_id": pid}, limit=2000)
        }
        prepared: list[dict] = []
        for position, source in enumerate(rows, start=1):
            characteristic = _text(source.get("characteristic") or source.get("Parameter"))
            if not characteristic:
                continue
            sequence = int(source.get("sequence_no") or source.get("Sequence") or position)
            ctype = _text(source.get("characteristic_type") or source.get("Type") or "NUMBER").upper()
            if ctype in {"VARIABLE"}: ctype = "NUMBER"
            if ctype in {"ATTRIBUTE"}: ctype = "TEXT"
            specification = _text(source.get("specification") or source.get("Specification")) or None
            lower_spec = _number(source.get("lower_spec") if "lower_spec" in source else source.get("Minimum"))
            upper_spec = _number(source.get("upper_spec") if "upper_spec" in source else source.get("Maximum"))
            if ctype == "TEXT":
                if not specification:
                    raise ValueError(f"Text Specification is required for {characteristic}.")
                lower_spec = upper_spec = None
            else:
                metadata = row_metadata(source)
                method = str(metadata.get("inspection_method") or GENERAL_METLAB).upper()
                if lower_spec is None and upper_spec is None and not (method == BEND_TEST and specification):
                    raise ValueError(f"Minimum or Maximum Specification is required for numeric parameter {characteristic}.")
            payload_row = {
                "id": str((existing.get(sequence) or {}).get("id") or source.get("id") or "") or None,
                "inspection_plan_id": pid,
                "sequence_no": sequence,
                "characteristic_no": _text(source.get("characteristic_no") or source.get("Characteristic No")) or None,
                "characteristic": characteristic,
                "specification": specification,
                "lower_spec": lower_spec,
                "upper_spec": upper_spec,
                "unit": _text(source.get("unit") or source.get("Unit")) or None,
                "characteristic_type": ctype,
                "special_class": _text(source.get("special_class") or source.get("Special Class")) or None,
                "checking_method": _text(source.get("checking_method") or source.get("Checking Method")) or None,
                "checking_aid_text": _text(source.get("checking_aid_text") or source.get("Checking Aid")) or None,
                "sample_size": int(source.get("sample_size") or source.get("Sample Size") or payload.get("default_sample_size") or 1),
                "frequency": _text(source.get("frequency") or source.get("Frequency")) or None,
                "reaction_plan": _text(source.get("reaction_plan") or source.get("Reaction Plan")) or None,
                "report_section": _text(source.get("report_section") or source.get("Section") or payload.get("layout_type")) or None,
                "is_mandatory": bool(source.get("is_mandatory", source.get("Mandatory", True))),
                "allow_na": bool(source.get("allow_na", source.get("Allow NA", False))),
                "decimal_places": int(source.get("decimal_places") or source.get("Decimal Places") or 3),
                "source_row": int(source.get("source_row") or source.get("Source Row") or 0) or None,
                "layout_metadata": source.get("layout_metadata") or {},
                "status": _text(source.get("status") or source.get("Status") or "ACTIVE").upper(),
            }
            if not payload_row["id"]:
                payload_row.pop("id")
            prepared.append(payload_row)
        self.repo.bulk_upsert("inspection_plan_characteristics", prepared, on_conflict="id")
        return plan

    def parse_dimensional_workbook(self, uploaded: Any) -> dict[str, Any]:
        content = uploaded.getvalue() if hasattr(uploaded, "getvalue") else uploaded.read()
        return parse_dimensional_workbook_bytes(content, getattr(uploaded, "name", "Dimensional Report.xlsx"))

    def next_number(self, layout_type: str) -> str:
        code = "DIMENSIONAL_REPORT" if layout_type == "DIMENSIONAL" else "METLAB_REPORT"
        return str(self.repo.rpc("qsms_next_document_number", {"p_sequence_code": code}) or "")

    def dimensional_reports(self) -> list[dict]:
        return annotate_transaction_rows(self.repo,self.repo.select("inspection_reports", eq={"report_type": "DIMENSIONAL"}, order_by="created_at", desc=True, limit=4000))

    def get_dimensional(self, report_id: str | None) -> dict | None:
        return self.repo.get("inspection_reports", report_id)

    def dimensional_results(self, report_id: str) -> list[dict]:
        return self.repo.select("inspection_results", eq={"inspection_report_id": report_id}, order_by="sequence_no", limit=2000)

    def save_dimensional(self, payload: Mapping[str, Any], result_rows: Sequence[Mapping[str, Any]], report_id: str | None = None) -> dict:
        report = self.repo.update("inspection_reports", report_id, payload) if report_id else self.repo.insert("inspection_reports", payload)
        rid = str(report["id"])
        existing = {
            str(row.get("inspection_plan_characteristic_id") or row.get("sequence_no") or ""): row
            for row in self.dimensional_results(rid)
        }
        prepared: list[dict] = []
        for position, row in enumerate(result_rows, start=1):
            key = str(row.get("inspection_plan_characteristic_id") or row.get("sequence_no") or position)
            payload_row = {
                "id": str((existing.get(key) or {}).get("id") or "") or None,
                "inspection_report_id": rid,
                "inspection_plan_characteristic_id": row.get("inspection_plan_characteristic_id") or None,
                "sequence_no": int(row.get("sequence_no") or position),
                "characteristic_no": _text(row.get("characteristic_no")) or None,
                "characteristic": _text(row.get("characteristic")),
                "specification": _text(row.get("specification")) or None,
                "lower_spec": _number(row.get("lower_spec")),
                "upper_spec": _number(row.get("upper_spec")),
                "unit": _text(row.get("unit")) or None,
                "checking_aid": _text(row.get("checking_aid")) or None,
                "observations": list(row.get("observations") or []),
                "attribute_result": _text(row.get("attribute_result")) or None,
                "result": _text(row.get("result") or "NOT_EVALUATED").upper(),
                "remarks": _text(row.get("remarks")) or None,
                "applicability": _text(row.get("applicability") or "APPLICABLE").upper(),
                "report_section": _text(row.get("report_section") or payload.get("layout_type_name") or "DIMENSIONAL") or None,
                "observation_count": max(1, len(list(row.get("observations") or []))),
            }
            if not payload_row["id"]:
                payload_row.pop("id")
            prepared.append(payload_row)
        self.repo.bulk_upsert("inspection_results", prepared, on_conflict="id")
        return report

    def metlab_reports(self) -> list[dict]:
        return annotate_transaction_rows(self.repo,self.repo.select("lab_tests", eq={"test_type": "METLAB"}, order_by="created_at", desc=True, limit=4000))

    def get_metlab(self, report_id: str | None) -> dict | None:
        return self.repo.get("lab_tests", report_id)

    def rmtc_material_snapshot(self, inward: Mapping[str, Any]) -> dict[str, Any]:
        rmtc_id = str(inward.get("rmtc_approval_id") or "")
        part_id = str(inward.get("part_id") or "")
        rmtc = self.repo.get("rmtc_approvals", rmtc_id) or {}
        part = self.repo.get("parts", part_id) or {}
        chemistry = self.repo.select("rmtc_chemistry_results", eq={"rmtc_approval_id": rmtc_id, "part_id": part_id}, order_by="element", limit=200)
        jominy = self.repo.select("rmtc_jominy_results", eq={"rmtc_approval_id": rmtc_id, "part_id": part_id}, order_by="distance_mm", limit=200)
        jominy_requirements = self.repo.select("part_jominy_requirements", eq={"part_id": part_id, "status": "ACTIVE"}, order_by="sequence_no", limit=200)
        jominy_band = {str(row.get("jominy_distance_id")): row for row in jominy_requirements}
        jominy = [{**row, "minimum_hrc": (jominy_band.get(str(row.get("jominy_distance_id"))) or {}).get("minimum_hrc"), "maximum_hrc": (jominy_band.get(str(row.get("jominy_distance_id"))) or {}).get("maximum_hrc")} for row in jominy]
        requirements = self.repo.select("rmtc_requirement_results", eq={"rmtc_approval_id": rmtc_id, "part_id": part_id}, order_by="sequence_no", limit=300)
        grade = self.repo.get("material_grades", str(part.get("material_grade_id") or "")) or {}
        supplier = self.repo.get("parties", str(inward.get("supplier_id") or "")) or {}
        steel_mill = self.repo.get("parties", str(rmtc.get("steel_mill_id") or "")) or {}
        return {"rmtc": rmtc, "part": part, "grade": grade, "supplier": supplier, "steel_mill": steel_mill, "chemistry": chemistry, "jominy": jominy, "requirements": requirements, "chemistry_rows": chemistry, "jominy_rows": jominy, "requirement_rows": requirements}

    def save_metlab(self, payload: Mapping[str, Any], results: Mapping[str, Sequence[Mapping[str, Any]]] | Sequence[Mapping[str, Any]], report_id: str | None = None) -> dict:
        full_payload = dict(payload)
        if isinstance(results, Mapping):
            # Keep stable RMTC-style section keys for database validation and reporting.
            full_payload["results"] = {
                "rows": [dict(row) for row in results.get("rows", [])],
                "chemistry_rows": [dict(row) for row in results.get("chemistry_rows", [])],
                "jominy_rows": [dict(row) for row in results.get("jominy_rows", [])],
                "requirement_rows": [dict(row) for row in results.get("requirement_rows", [])],
                "case_depth_locations": [dict(row) for row in results.get("case_depth_locations", [])],
                "case_depth_traverse": [dict(row) for row in results.get("case_depth_traverse", [])],
                "case_depth_applicable": bool(results.get("case_depth_applicable", False)),
                "case_depth_na_reason": str(results.get("case_depth_na_reason") or "").strip() or None,
            }
        else:
            full_payload["results"] = {"rows": [dict(row) for row in results], "chemistry_rows": [], "jominy_rows": [], "requirement_rows": [], "case_depth_locations": [], "case_depth_traverse": [], "case_depth_applicable": False, "case_depth_na_reason": None}
        return self.repo.update("lab_tests", report_id, full_payload) if report_id else self.repo.insert("lab_tests", full_payload)

    def _report_employees(self, record: Mapping[str, Any]) -> dict[str, dict]:
        ids = [str(value) for value in (
            record.get("prepared_by_employee_id"), record.get("validated_by_employee_id"), record.get("approved_by_employee_id")
        ) if value]
        rows = self.repo.select("employees", in_={"id": ids}, limit=20) if ids else []
        return {str(row.get("id")): row for row in rows}

    def _report_microstructure_images(self, entity_type: str, entity_id: str, record: Mapping[str, Any], slots: int = 4) -> list[dict]:
        images: list[dict] = []
        try:
            service = AttachmentService(self.repo)
            attachments = service.list_active(entity_type, entity_id)
            by_type = {str(row.get("document_type") or ""): row for row in attachments}
            for slot in range(1, slots + 1):
                attachment = by_type.get(f"MICROSTRUCTURE_{slot}")
                data = b""
                if attachment:
                    try:
                        data = service.download(attachment)
                    except Exception:
                        data = b""
                images.append({
                    "slot": slot,
                    "caption": record.get(f"microstructure_caption_{slot}") or f"Microstructure Photo {slot}",
                    "bytes": data,
                    "file_name": (attachment or {}).get("file_name"),
                })
        except Exception:
            images = [{"slot": slot, "caption": record.get(f"microstructure_caption_{slot}") or f"Microstructure Photo {slot}", "bytes": b""} for slot in range(1, slots + 1)]
        return images

    def metlab_report_payload(self, report_id: str) -> dict:
        record = self.get_metlab(report_id) or {}
        if not record:
            raise ValueError("MetLAB report not found.")
        part = self.repo.get("parts", str(record.get("part_id") or "")) or {}
        inward = self.repo.get("inward_lots", str(record.get("inward_lot_id") or "")) or {}
        supplier = self.repo.get("parties", str(record.get("supplier_id") or inward.get("supplier_id") or "")) or {}
        steel_mill = self.repo.get("parties", str(record.get("steel_mill_id") or "")) or {}
        grade = self.repo.get("material_grades", str(record.get("material_grade_id") or part.get("material_grade_id") or "")) or {}
        customer = self.repo.get("parties", str(record.get("customer_id") or part.get("customer_id") or "")) or {}
        process = self.repo.get("processes", str(record.get("process_id") or "")) or {}
        stage = self.repo.get("inspection_stages", str(record.get("inspection_stage_id") or "")) or {}
        osp_rows = self.repo.select("v_qsms_osp_register", eq={"id": str(record.get("osp_job_id"))}, limit=1) if record.get("osp_job_id") else []
        osp_job = osp_rows[0] if osp_rows else {}
        osp_vendor = self.repo.get("parties", str(record.get("osp_vendor_id") or osp_job.get("vendor_id") or "")) or {}
        return {
            "record": record, "part": part, "inward": inward, "supplier": supplier, "osp_vendor": osp_vendor, "steel_mill": steel_mill,
            "customer": customer, "material_grade": grade, "process": process, "stage": stage, "osp_job": osp_job,
            "employees": self._report_employees(record),
            "results": dict(record.get("results") or {}),
            "microstructure_images": self._report_microstructure_images("METLAB_REPORT", report_id, record, 4),
        }

    def dimensional_report_payload(self, report_id: str) -> dict:
        record = self.get_dimensional(report_id) or {}
        if not record:
            raise ValueError("Dimensional report not found.")
        part = self.repo.get("parts", str(record.get("part_id") or "")) or {}
        inward = self.repo.get("inward_lots", str(record.get("inward_lot_id") or "")) or {}
        supplier = self.repo.get("parties", str(record.get("supplier_id") or inward.get("supplier_id") or "")) or {}
        customer = self.repo.get("parties", str(record.get("customer_id") or part.get("customer_id") or "")) or {}
        grade = self.repo.get("material_grades", str(record.get("material_grade_id") or part.get("material_grade_id") or "")) or {}
        process = self.repo.get("processes", str(record.get("process_id") or "")) or {}
        stage = self.repo.get("inspection_stages", str(record.get("inspection_stage_id") or "")) or {}
        osp_rows = self.repo.select("v_qsms_osp_register", eq={"id": str(record.get("osp_job_id"))}, limit=1) if record.get("osp_job_id") else []
        osp_job = osp_rows[0] if osp_rows else {}
        return {
            "record": record, "part": part, "inward": inward, "supplier": supplier, "customer": customer, "material_grade": grade,
            "process": process, "stage": stage, "osp_job": osp_job, "employees": self._report_employees(record), "results": self.dimensional_results(report_id),
        }

    @staticmethod
    def _standalone_final_payload(disposition: str, reason: str, validator: str, approver: str) -> dict[str, Any]:
        decision = _text(disposition).upper().replace(" ", "_")
        if decision not in FINAL_DISPOSITIONS:
            raise ValueError("Select On Hold, Accepted, Accepted Under Reserve or Rejected.")
        if decision in {"ON_HOLD", "ACCEPTED_UNDER_RESERVE", "REJECTED"} and not _text(reason):
            raise ValueError("A hold, reserve or rejection reason is mandatory.")
        now = datetime.now(timezone.utc).isoformat()
        return {
            "disposition": decision,
            "disposition_reason": _text(reason) or None,
            "validated_by_employee_id": validator,
            "approved_by_employee_id": approver,
            "validated_at": now,
            "decision_at": None if decision == "ON_HOLD" else now,
            "status": "ON_HOLD" if decision == "ON_HOLD" else "FINAL",
            "overall_result": "FAIL" if decision == "REJECTED" else ("HOLD" if decision in {"ON_HOLD", "ACCEPTED_UNDER_RESERVE"} else "PASS"),
        }

    def finalize_dimensional(self, report_id: str, disposition: str, reason: str, validator: str, approver: str) -> dict:
        record = self.get_dimensional(report_id) or {}
        # Standalone reports intentionally have no Material Inward / OSP parent, so
        # they must not call the linked-flow RPC which refreshes an inward quality gate.
        if record and not record.get("inward_lot_id") and not record.get("osp_job_id"):
            payload = self._standalone_final_payload(disposition, reason, validator, approver)
            bad = sum(1 for row in self.dimensional_results(report_id) if _text(row.get("result")).upper() not in {"PASS", "NOT_APPLICABLE"})
            if payload["disposition"] == "ACCEPTED" and bad:
                raise ValueError("Accepted is allowed only when every applicable characteristic passes.")
            return self.repo.update("inspection_reports", report_id, payload)
        return self.repo.rpc("qsms_finalize_dimensional_report", {
            "p_report_id": report_id,
            "p_disposition": disposition,
            "p_reason": reason or None,
            "p_validated_by_employee_id": validator,
            "p_approved_by_employee_id": approver,
        }) or {}

    def finalize_metlab(self, report_id: str, disposition: str, reason: str, validator: str, approver: str) -> dict:
        record = self.get_metlab(report_id) or {}
        if record and not record.get("inward_lot_id") and not record.get("osp_job_id"):
            payload = self._standalone_final_payload(disposition, reason, validator, approver)
            result_map = dict(record.get("results") or {})
            all_rows: list[dict] = []
            for key in ("rows", "chemistry_rows", "jominy_rows", "requirement_rows"):
                all_rows.extend(dict(row) for row in (result_map.get(key) or []))
            bad = sum(1 for row in all_rows if _text(row.get("result")).upper() not in {"PASS", "NOT_APPLICABLE"})
            if payload["disposition"] == "ACCEPTED" and bad and not _text(reason):
                raise ValueError("Manual acceptance reason is mandatory when applicable MetLAB results do not all pass.")
            return self.repo.update("lab_tests", report_id, payload)
        return self.repo.rpc("qsms_finalize_metlab_report", {
            "p_report_id": report_id,
            "p_disposition": disposition,
            "p_reason": reason or None,
            "p_validated_by_employee_id": validator,
            "p_approved_by_employee_id": approver,
        }) or {}

    @staticmethod
    def evaluate_characteristic(row: Mapping[str, Any], observations: Sequence[Any], not_applicable: bool = False) -> str:
        if not_applicable:
            return "NOT_APPLICABLE"
        values = [value for value in observations if _text(value)]
        if not values:
            return "NOT_EVALUATED"
        characteristic_type = _text(row.get("characteristic_type") or "NUMBER").upper()
        if characteristic_type in {"TEXT", "ATTRIBUTE"}:
            specification = _text(row.get("specification"))
            # Preserve legacy ATTRIBUTE layouts with no controlled text specification.
            if not specification and characteristic_type == "ATTRIBUTE":
                return "PASS" if all(_attribute_pass(value) for value in values) else "FAIL"
            if not specification:
                return "FAIL"
            def normalized(value: Any) -> str:
                return " ".join(re.findall(r"[a-z0-9]+", _text(value).casefold()))
            expected = normalized(specification)
            expected_tokens = set(expected.split())
            for value in values:
                actual = normalized(value)
                actual_tokens = set(actual.split())
                sequence_score = SequenceMatcher(None, expected, actual).ratio() if expected and actual else 0.0
                token_score = (len(expected_tokens & actual_tokens) / len(expected_tokens)) if expected_tokens else 0.0
                if max(sequence_score, token_score) < 0.75:
                    return "FAIL"
            return "PASS"
        lower = _number(row.get("lower_spec"))
        upper = _number(row.get("upper_spec"))
        numeric = [_number(value) for value in values]
        if any(value is None for value in numeric):
            return "FAIL"
        for value in numeric:
            if lower is not None and float(value) < lower:
                return "FAIL"
            if upper is not None and float(value) > upper:
                return "FAIL"
        return "PASS"

    def upload_attachment(self, entity_type: str, entity_id: str, document_type: str, file: Any, table: str, field: str) -> str:
        client = get_session_client()
        if client is None:
            raise RuntimeError("Live Supabase session is required for attachment upload.")
        ext = Path(file.name).suffix.lower() or ".bin"
        content = file.getvalue()
        folder = entity_type.lower().replace("_", "-")
        path = f"{self.repo.tenant_id}/{folder}/{entity_id}/{document_type.lower()}_{hashlib.sha1(file.name.encode()).hexdigest()[:8]}{ext}"
        client.storage.from_("quality-documents").upload(path, content, {"content-type": file.type or "application/octet-stream", "upsert": "true"})
        attachment = {
            "entity_type": entity_type,
            "entity_id": entity_id,
            "document_type": document_type,
            "file_name": file.name,
            "object_path": path,
            "mime_type": file.type,
            "size_bytes": len(content),
            "checksum": hashlib.sha256(content).hexdigest(),
            "status": "ACTIVE",
        }
        existing = self.repo.find_one("document_attachments", eq={"entity_type": entity_type, "entity_id": entity_id, "document_type": document_type})
        if existing:
            self.repo.update("document_attachments", str(existing["id"]), attachment)
        else:
            self.repo.insert("document_attachments", attachment)
        self.repo.update(table, entity_id, {field: path})
        return path
