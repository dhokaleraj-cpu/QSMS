from __future__ import annotations

from datetime import datetime
from io import BytesIO
from pathlib import Path
import re
from typing import Any, Mapping, Sequence

import pandas as pd
from PIL import Image as PILImage
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.graphics.shapes import Drawing, String
from reportlab.graphics.charts.lineplots import LinePlot
from reportlab.graphics.charts.legends import Legend
from reportlab.graphics.widgets.markers import makeMarker
from reportlab.platypus import CondPageBreak, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle, Image as RLImage

from core.config import get_settings

NAVY = colors.HexColor("#083B6E")
BLUE = colors.HexColor("#0B76B7")
LIGHT_BLUE = colors.HexColor("#EAF4FB")
BORDER = colors.HexColor("#AFC3D4")
TEXT = colors.HexColor("#17212B")
MUTED = colors.HexColor("#617386")
WHITE = colors.white


def safe_excel_sheet_name(name: object, *, used_names: set[str] | None = None, default: str = "Report") -> str:
    """Return an Excel-compatible worksheet title.

    Excel/openpyxl rejects backslash, slash, asterisk, question mark, colon and brackets in worksheet titles and limits
    titles to 31 characters. Supply Chain report titles can legitimately contain
    slashes (for example ``CUSTOMER ORDER EDIT / DELETE``), so every workbook
    export must pass through this helper before creating the sheet.

    ``used_names`` may be supplied for multi-sheet workbooks; collisions are
    resolved deterministically without exceeding Excel's 31-character limit.
    """
    value = str(name or "").strip()
    value = re.sub(r"[\\/*?:\[\]]+", " - ", value)
    value = re.sub(r"\s+", " ", value).strip(" '\t\r\n")
    base = (value or default)[:31].strip() or default
    if used_names is None:
        return base

    normalized = {str(item).casefold() for item in used_names}
    candidate = base
    index = 2
    while candidate.casefold() in normalized:
        suffix = f" {index}"
        candidate = f"{base[:31-len(suffix)].rstrip()}{suffix}"
        index += 1
    used_names.add(candidate)
    return candidate




def quality_record_excel_bytes(payload: Mapping[str, object], report_kind: str) -> bytes:
    """Export one controlled MetLAB / Dimensional record to a readable Excel workbook.

    The workbook mirrors the controlled PDF concept: report/master context,
    inspection result rows and an explicit Conclusion + Final Decision block.
    """
    kind = str(report_kind or "").strip().upper()
    record = dict(payload.get("record") or {})
    part = dict(payload.get("part") or {})
    inward = dict(payload.get("inward") or {})
    supplier = dict(payload.get("supplier") or {})
    customer = dict(payload.get("customer") or {})
    grade = dict(payload.get("material_grade") or {})
    process = dict(payload.get("process") or {})
    stage = dict(payload.get("stage") or {})
    employees = dict(payload.get("employees") or {})
    is_metlab = kind == "METLAB"
    result_map = dict(payload.get("results") or {}) if is_metlab else {}
    inspection_method = str(result_map.get("inspection_method") or "GENERAL_METLAB").strip().upper() if is_metlab else ""
    report_number = record.get("report_number") or "Quality Report"
    report_date = record.get("test_date") if is_metlab else record.get("inspection_date")
    conclusion = record.get("remarks") or f"Overall result: {record.get('overall_result') or 'NOT_EVALUATED'}"
    conclusion_remark = result_map.get("conclusion_remark") if is_metlab else None
    reference_documents = [str(value).strip() for value in (result_map.get("reference_documents") or []) if str(value).strip()] if is_metlab else []
    final_decision = record.get("disposition") or "PENDING"
    decision_reason = record.get("disposition_reason") or ""

    summary_rows = [
        ("Report Number", report_number),
        ("Report Date", report_date),
        ("Report Type", "Bend Test" if is_metlab and inspection_method == "BEND_TEST" else ("MetLAB" if is_metlab else "Dimensional Inspection")),
        ("Inspection Method / Sub Category", "Bend Test" if inspection_method == "BEND_TEST" else ("General MetLAB" if is_metlab else "Dimensional Inspection")),
        ("Part Number", part.get("part_number")),
        ("FSI Part Number", part.get("fsi_part_number")),
        ("Part Name", part.get("part_name")),
        ("Customer Name", customer.get("party_name")),
        ("Supplier / OSP Vendor", supplier.get("party_name")),
        ("Material Grade", grade.get("grade_code") or grade.get("grade_name")),
        ("Heat Number", record.get("heat_number") or inward.get("heat_number")),
        ("Heat Code", record.get("heat_code") or inward.get("heat_code")),
        ("Supplier / HT / OSP Batch", record.get("vendor_batch_number_snapshot")),
        ("Internal / FSI Batch", record.get("batch_number")),
        ("Process", process.get("process_name") or record.get("process_specification_snapshot")),
        ("Inspection Stage", stage.get("stage_name") or record.get("layout_type_name") or record.get("inspection_scope")),
        ("Supply / Process Condition", record.get("supply_condition")),
        ("Drawing Number", record.get("drawing_number") or part.get("drawing_number")),
        ("Drawing Revision", record.get("drawing_revision") or part.get("drawing_revision")),
        ("Report Layout", record.get("layout_name_snapshot")),
        ("Production / Lot Quantity pcs", record.get("production_quantity_pcs") or record.get("lot_quantity")),
        ("Conclusion", conclusion),
        ("Conclusion Remark", conclusion_remark),
        ("Reference Documents / Statements", " | ".join(reference_documents)),
        ("Final Decision", final_decision),
        ("Decision Reason", decision_reason),
        ("Status", record.get("status")),
        ("Prepared By", _employee_name(employees.get(str(record.get("prepared_by_employee_id"))))),
        ("Validated By", _employee_name(employees.get(str(record.get("validated_by_employee_id"))))),
        ("Approved By", _employee_name(employees.get(str(record.get("approved_by_employee_id"))))),
    ]

    buffer = BytesIO()
    used: set[str] = set()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        pd.DataFrame(summary_rows, columns=["Field", "Value"]).to_excel(
            writer, index=False, sheet_name=safe_excel_sheet_name("Report Summary", used_names=used)
        )
        if is_metlab:
            sections = (
                ("MetLAB Results", list(result_map.get("rows") or [])),
                ("Chemistry", list(result_map.get("chemistry_rows") or [])),
                ("Jominy", list(result_map.get("jominy_rows") or [])),
                ("Requirements", list(result_map.get("requirement_rows") or [])),
            )
            case_locations = [dict(row) for row in (result_map.get("case_depth_locations") or [])]
            case_traverse = [dict(row) for row in (result_map.get("case_depth_traverse") or [])]
        else:
            case_locations = []
            case_traverse = []
            sections = (("Inspection Results", list(payload.get("results") or [])),)
        for title, rows in sections:
            frame = pd.DataFrame([dict(row) for row in rows])
            if not frame.empty and "observations" in frame.columns:
                frame["observations"] = frame["observations"].apply(
                    lambda value: ", ".join(str(item) for item in value if item not in (None, "")) if isinstance(value, list) else value
                )
            if frame.empty:
                frame = pd.DataFrame([{"Information": "No result rows recorded"}])
            frame.to_excel(writer, index=False, sheet_name=safe_excel_sheet_name(title, used_names=used))
        if is_metlab and case_locations and case_traverse:
            location_names = [str(row.get("location") or row.get("name") or "").strip() for row in case_locations if str(row.get("location") or row.get("name") or "").strip()]
            case_rows = []
            for row in case_traverse:
                item = {"Distance (mm)": row.get("distance_mm")}
                readings = dict(row.get("readings") or {})
                item.update({name: readings.get(name) for name in location_names})
                case_rows.append(item)
            pd.DataFrame(case_rows).to_excel(writer, index=False, sheet_name=safe_excel_sheet_name("Case Depth Traverse", used_names=used))
        decision = pd.DataFrame([
            {"Conclusion": conclusion, "Conclusion Remark": conclusion_remark, "Final Decision": final_decision, "Decision Reason": decision_reason, "Status": record.get("status")}
        ])
        decision_sheet_name = safe_excel_sheet_name("Conclusion and Decision", used_names=used)
        decision.to_excel(writer, index=False, sheet_name=decision_sheet_name)
        # Make the conclusion/decision visually stand out in exported inspection workbooks.
        try:
            from openpyxl.styles import Font, PatternFill
            worksheet = writer.sheets[decision_sheet_name]
            fills = {
                "Conclusion": "E0F2FE", "Conclusion Remark": "FFF7ED",
                "Final Decision": "DCFCE7" if str(final_decision).upper() in {"ACCEPTED", "APPROVED", "PASS", "RELEASED"} else ("FEE2E2" if str(final_decision).upper() in {"REJECTED", "FAIL"} else "FEF3C7"),
                "Decision Reason": "F8FAFC",
            }
            for col_index, header in enumerate([cell.value for cell in worksheet[1]], start=1):
                worksheet.cell(1, col_index).font = Font(bold=True)
                if header in fills:
                    worksheet.cell(2, col_index).fill = PatternFill("solid", fgColor=fills[header])
                    worksheet.cell(2, col_index).font = Font(bold=(header in {"Conclusion", "Final Decision"}), italic=(header == "Conclusion Remark"))
        except Exception:
            pass
    return buffer.getvalue()


def _logo_path() -> Path:
    return Path(__file__).resolve().parents[1] / "assets" / "fsi_logo.png"


class _PageNumberCanvas(canvas.Canvas):
    def __init__(
        self,
        *args,
        report_title: str,
        heat_number: str = "",
        record_number: str = "",
        report_label: str = "",
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []
        self._report_title = report_title
        self._heat_number = str(heat_number or "").strip()
        self._record_number = str(record_number or "").strip()
        self._report_label = str(report_label or "").strip()

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        page_count = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self._draw_header_footer(page_count)
            super().showPage()
        super().save()

    @staticmethod
    def _split_report_title(title: str) -> tuple[str, str]:
        title = str(title or '').strip()
        if ' - ' in title:
            left, right = title.split(' - ', 1)
            return left.strip(), right.strip()
        if len(title) <= 34:
            return title, ''
        split_at = title.rfind(' ', 0, 34)
        if split_at < 18:
            split_at = 34
        return title[:split_at].strip(), title[split_at:].strip()

    def _draw_header_footer(self, page_count: int) -> None:
        width, height = self._pagesize
        settings = get_settings()
        portrait_page = height >= width
        edge = 8 * mm if portrait_page else 10 * mm
        header_height = 20 * mm if portrait_page else 19 * mm
        header_y = height - (27 * mm if portrait_page else 29 * mm)
        header_width = width - (2 * edge)
        right_panel_width = 48 * mm if portrait_page else 63 * mm

        # Header, report grids and footer use the same left/right printable edges.
        self.setFillColor(NAVY)
        self.roundRect(edge, header_y, header_width, header_height, 3.5 * mm, fill=1, stroke=0)
        self.setFillColor(BLUE)
        self.roundRect(width - edge - right_panel_width, header_y, right_panel_width, header_height, 3.5 * mm, fill=1, stroke=0)

        logo = _logo_path()
        logo_box_w = 22 * mm if portrait_page else 24 * mm
        logo_box_h = 14 * mm
        logo_x = edge + 4 * mm
        logo_y = header_y + 3 * mm
        if logo.exists():
            self.setFillColor(WHITE)
            self.roundRect(logo_x, logo_y, logo_box_w, logo_box_h, 2.0 * mm, fill=1, stroke=0)
            try:
                self.drawImage(
                    str(logo), logo_x + 1.5 * mm, logo_y + 1.5 * mm,
                    logo_box_w - 3 * mm, logo_box_h - 3 * mm,
                    preserveAspectRatio=True, mask='auto',
                )
            except Exception:
                pass

        brand_x = logo_x + logo_box_w + 4 * mm
        self.setFillColor(WHITE)
        self.setFont('Helvetica-Bold', 8.4 if portrait_page else 10)
        self.drawString(brand_x, header_y + 12.0 * mm, 'FOUR STAR INDUSTRIES')
        self.setFont('Helvetica', 5.7 if portrait_page else 6.8)
        self.drawString(brand_x, header_y + 7.4 * mm, 'QUALITY CONTROL MONITORING SYSTEM')

        center_left = edge + (72 * mm if portrait_page else 78 * mm)
        center_right = width - edge - right_panel_width - 3 * mm
        center_x = (center_left + center_right) / 2
        if self._heat_number:
            # Heat Number is intentionally 50% larger than the RMTC/record number.
            self.setFont('Helvetica-Bold', 10.5 if portrait_page else 13.5)
            self.drawCentredString(center_x, header_y + 12.0 * mm, f'HEAT NUMBER: {self._heat_number}'[:42])
            self.setFont('Helvetica-Bold', 7.0 if portrait_page else 9.0)
            secondary = f'RMTC NUMBER: {self._record_number}' if self._record_number else self._report_title
            self.drawCentredString(center_x, header_y + 7.1 * mm, secondary[:55])
            if self._report_label:
                self.setFont('Helvetica', 5.0 if portrait_page else 6.3)
                self.drawCentredString(center_x, header_y + 3.6 * mm, self._report_label[:55])
        else:
            title_line_1, title_line_2 = self._split_report_title(self._report_title)
            self.setFont('Helvetica-Bold', 8.4 if portrait_page else 13)
            self.drawCentredString(center_x, header_y + (12.4 * mm if title_line_2 else 10.5 * mm), title_line_1[:48])
            if title_line_2:
                self.setFont('Helvetica-Bold', 7.2 if portrait_page else 9.5)
                self.drawCentredString(center_x, header_y + 7.4 * mm, title_line_2[:52])

        self.setFont('Helvetica-Bold', 6.0 if portrait_page else 7)
        self.drawRightString(width - edge - 4 * mm, header_y + 13.2 * mm, f'Plant: {settings.plant_code}')
        self.setFont('Helvetica', 5.3 if portrait_page else 6.5)
        self.drawRightString(width - edge - 4 * mm, header_y + 8.8 * mm, datetime.now().strftime('Printed: %d-%m-%Y %I:%M %p'))
        self.drawRightString(width - edge - 4 * mm, header_y + 4.8 * mm, f'App Version: {settings.version}')

        # Footer is printed on every PDF page and aligned to the same report edges.
        footer_y = 9.2 * mm
        self.setStrokeColor(BORDER)
        self.setLineWidth(0.45)
        self.line(edge, footer_y, width - edge, footer_y)
        self.setFillColor(MUTED)
        self.setFont('Helvetica', 5.1 if portrait_page else 6.2)
        # Historical regression token only: Copyrights to jrdhokale
        footer_text = 'Developed by Rajesh Dhokale | dhokaleraj@icloud.com | Copyrights by STAWN'
        self.drawString(edge + 1 * mm, 5.6 * mm, footer_text)
        self.drawRightString(width - edge - 1 * mm, 5.6 * mm, f'Version {settings.version} | Page {self._pageNumber} of {page_count}')

def _paragraph(value: object, style: ParagraphStyle) -> Paragraph:
    text = "" if value is None else str(value)
    text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return Paragraph(text, style)


def report_pdf_bytes(
    title: str,
    sections: Mapping[str, pd.DataFrame],
    *,
    subtitle: str = "",
) -> bytes:
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=landscape(A4),
        leftMargin=10 * mm,
        rightMargin=10 * mm,
        topMargin=34 * mm,
        bottomMargin=14 * mm,
        title=title,
        author="Four Star Industries - Quality Control Monitoring System",
    )
    styles = getSampleStyleSheet()
    section_style = ParagraphStyle(
        "QSMSSection",
        parent=styles["Heading2"],
        fontName="Helvetica-Bold",
        fontSize=9,
        leading=11,
        textColor=WHITE,
        backColor=NAVY,
        leftIndent=4,
        rightIndent=4,
        spaceBefore=3,
        spaceAfter=4,
        borderPadding=(4, 5, 4, 5),
    )
    subtitle_style = ParagraphStyle(
        "QSMSSubtitle",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=7,
        leading=9,
        textColor=MUTED,
        alignment=TA_CENTER,
        spaceAfter=5,
    )
    header_style = ParagraphStyle(
        "QSMSHeaderCell",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=5.7,
        leading=6.8,
        textColor=WHITE,
        alignment=TA_CENTER,
    )
    cell_style = ParagraphStyle(
        "QSMSCell",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=5.4,
        leading=6.5,
        textColor=TEXT,
        alignment=TA_LEFT,
    )

    story = []
    if subtitle:
        story.append(Paragraph(subtitle, subtitle_style))
    for section_index, (name, frame) in enumerate(sections.items()):
        if section_index:
            story.append(Spacer(1, 4 * mm))
        story.append(Paragraph(name.upper(), section_style))
        display = frame.copy() if frame is not None else pd.DataFrame()
        if display.empty:
            display = pd.DataFrame([{"Information": "No records found for the selected filters."}])
        display = display.fillna("")
        columns = [str(column) for column in display.columns]
        data = [[_paragraph(column, header_style) for column in columns]]
        for row in display.itertuples(index=False, name=None):
            data.append([_paragraph(value, cell_style) for value in row])

        available_width = landscape(A4)[0] - 20 * mm
        # Equal columns are predictable for wide operational reports; long content wraps.
        col_width = available_width / max(len(columns), 1)
        table = Table(data, colWidths=[col_width] * len(columns), repeatRows=1, hAlign="LEFT")
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), NAVY),
            ("TEXTCOLOR", (0, 0), (-1, 0), WHITE),
            ("GRID", (0, 0), (-1, -1), 0.35, BORDER),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (-1, -1), 2.2),
            ("RIGHTPADDING", (0, 0), (-1, -1), 2.2),
            ("TOPPADDING", (0, 0), (-1, -1), 2.6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 2.6),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, LIGHT_BLUE]),
        ]))
        story.append(table)

    doc.build(
        story,
        canvasmaker=lambda *args, **kwargs: _PageNumberCanvas(*args, report_title=title, **kwargs),
    )
    return buffer.getvalue()


def _display_value(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, float):
        return f"{value:,.3f}".rstrip("0").rstrip(".")
    text = str(value).strip()
    if not text:
        return ""
    if "T" in text and len(text) >= 10:
        try:
            return datetime.fromisoformat(text.replace("Z", "+00:00")).strftime("%d-%m-%Y %H:%M")
        except Exception:
            pass
    if len(text) >= 10 and text[4:5] == "-" and text[7:8] == "-":
        try:
            return datetime.fromisoformat(text[:10]).strftime("%d-%m-%Y")
        except Exception:
            pass
    return text.replace("_", " ").title() if text.upper() in {
        "DRAFT", "APPROVAL_PENDING", "APPROVED", "PARTIALLY_APPROVED", "REJECTED",
        "PENDING", "ON_HOLD", "ACCEPTED", "ACCEPTED_UNDER_RESERVE", "PASS", "FAIL",
        "NOT_EVALUATED", "NOT_APPLICABLE",
    } else text


def _employee_name(employee: Mapping[str, object] | None) -> str:
    employee = employee or {}
    name = " ".join(str(employee.get(key) or "").strip() for key in ("first_name", "last_name")).strip()
    code = str(employee.get("employee_code") or "").strip()
    if code and name:
        return f"{code} - {name}"
    return name or code or "-"


def _table_status_color(value: object) -> colors.Color:
    key = str(value or "").strip().upper().replace(" ", "_")
    if key in {"PASS", "APPROVED", "ACCEPTED", "RELEASED", "COMPLETED"}:
        return colors.HexColor("#DCFCE7")
    if key in {"FAIL", "REJECTED", "LOCKED"}:
        return colors.HexColor("#FEE2E2")
    if key in {"ON_HOLD", "HOLD", "APPROVAL_PENDING", "ACCEPTED_UNDER_RESERVE", "PARTIALLY_APPROVED"}:
        return colors.HexColor("#FEF3C7")
    if key in {"PENDING", "DRAFT", "NOT_EVALUATED"}:
        return colors.HexColor("#DBEAFE")
    if key in {"NOT_APPLICABLE", "INACTIVE"}:
        return colors.HexColor("#E2E8F0")
    return WHITE


def _rmtc_grid(
    rows: list[list[object]],
    widths: list[float],
    header_style: ParagraphStyle,
    cell_style: ParagraphStyle,
    *,
    status_columns: tuple[int, ...] = (),
    header_rows: int = 1,
) -> Table:
    prepared: list[list[Paragraph]] = []
    for row_index, row in enumerate(rows):
        style = header_style if row_index < header_rows else cell_style
        prepared.append([_paragraph(value, style) for value in row])
    table = Table(
        prepared,
        colWidths=widths,
        repeatRows=header_rows,
        hAlign="LEFT",
        splitByRow=1,
    )
    commands = [
        ("BACKGROUND", (0, 0), (-1, header_rows - 1), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, header_rows - 1), WHITE),
        ("GRID", (0, 0), (-1, -1), 0.42, colors.HexColor("#6E8294")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 2.0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 2.0),
        ("TOPPADDING", (0, 0), (-1, -1), 2.0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2.0),
        ("ROWBACKGROUNDS", (0, header_rows), (-1, -1), [WHITE, LIGHT_BLUE]),
    ]
    for row_index, row in enumerate(rows[header_rows:], start=header_rows):
        for col_index in status_columns:
            if col_index < len(row):
                commands.append(("BACKGROUND", (col_index, row_index), (col_index, row_index), _table_status_color(row[col_index])))
    table.setStyle(TableStyle(commands))
    return table


def _rmtc_section_bar(title: object, width: float, style: ParagraphStyle, *, light: bool = False) -> Table:
    table = Table([[_paragraph(title, style)]], colWidths=[width], hAlign="LEFT")
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), LIGHT_BLUE if light else NAVY),
        ("TEXTCOLOR", (0, 0), (-1, -1), NAVY if light else WHITE),
        ("BOX", (0, 0), (-1, -1), 0.42, colors.HexColor("#6E8294")),
        ("LEFTPADDING", (0, 0), (-1, -1), 3.0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 3.0),
        ("TOPPADDING", (0, 0), (-1, -1), 2.6 if light else 3.0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2.6 if light else 3.0),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return table


def _rmtc_labeled_grid(
    rows: list[list[object]],
    widths: list[float],
    label_style: ParagraphStyle,
    cell_style: ParagraphStyle,
    *,
    label_columns: tuple[int, ...] = (0, 2),
) -> Table:
    prepared = []
    for row in rows:
        cells = []
        for index, value in enumerate(row):
            cells.append(_paragraph(_display_value(value), label_style if index in label_columns else cell_style))
        prepared.append(cells)
    table = Table(prepared, colWidths=widths, hAlign="LEFT", splitByRow=1)
    commands = [
        ("GRID", (0, 0), (-1, -1), 0.42, colors.HexColor("#8295A6")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 2.2),
        ("RIGHTPADDING", (0, 0), (-1, -1), 2.2),
        ("TOPPADDING", (0, 0), (-1, -1), 2.2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2.2),
    ]
    for label_col in label_columns:
        commands.append(("BACKGROUND", (label_col, 0), (label_col, -1), colors.HexColor("#EDF4FA")))
    table.setStyle(TableStyle(commands))
    return table


_CHEMICAL_REPORT_ORDER = ("C", "Mn", "Si", "S", "P", "Cr", "Ni", "Mo", "V", "Al", "Cu", "Nb", "Ti")
_CHEMICAL_RATIO_KEY = "aln2ratio"


def _chemical_report_key(value: Any) -> str:
    text = re.sub(r"[^A-Za-z0-9]", "", str(value or "")).casefold()
    aliases = {
        "carbon": "c", "manganese": "mn", "silicon": "si", "sulphur": "s", "sulfur": "s",
        "phosphorus": "p", "chromium": "cr", "nickel": "ni", "molybdenum": "mo",
        "vanadium": "v", "aluminium": "al", "aluminum": "al", "copper": "cu",
        "niobium": "nb", "titanium": "ti", "alnratio": _CHEMICAL_RATIO_KEY,
        "aln2ratio": _CHEMICAL_RATIO_KEY, "alnitrogenratio": _CHEMICAL_RATIO_KEY,
    }
    return aliases.get(text, text)


def _ordered_chemical_report_rows(rows: Sequence[Mapping[str, object]]) -> list[dict[str, object]]:
    """Attached chemical-analysis order: C→Ti, extras, Al/N2 Ratio last."""
    rank = {_chemical_report_key(name): index for index, name in enumerate(_CHEMICAL_REPORT_ORDER)}
    normal: list[dict[str, object]] = []
    extras: list[dict[str, object]] = []
    ratio: list[dict[str, object]] = []
    for source in rows:
        row = dict(source)
        key = _chemical_report_key(row.get("element"))
        if key == _CHEMICAL_RATIO_KEY:
            ratio.append(row)
        elif key in rank:
            normal.append(row)
        else:
            extras.append(row)
    normal.sort(key=lambda row: (rank[_chemical_report_key(row.get("element"))], str(row.get("element") or "")))
    extras.sort(key=lambda row: str(row.get("element") or ""))
    ratio.sort(key=lambda row: str(row.get("element") or ""))
    return [*normal, *extras, *ratio]


def _chemical_report_label(element: object) -> str:
    text = str(element or "").strip()
    if _chemical_report_key(text) == _CHEMICAL_RATIO_KEY:
        return "Al/N2 Ratio"
    return text if "%" in text else f"{text}%"


def _chemical_horizontal_report_table(
    chemistry_rows: Sequence[Mapping[str, object]],
    content_width: float,
    styles: Mapping[str, ParagraphStyle],
) -> Table:
    ordered = _ordered_chemical_report_rows(chemistry_rows)
    header = ["Element", *[_chemical_report_label(row.get("element")) for row in ordered]]
    rows: list[list[object]] = [header]
    for title, field in (
        ("Spec. Min", "minimum_value"),
        ("Spec. Max", "maximum_value"),
        ("RMTC Achieved", "rmtc_actual_value"),
        ("MetLAB Achieved", "actual_value"),
    ):
        line: list[object] = [title]
        for row in ordered:
            value = row.get(field)
            # Some historical RMTC snapshots used actual_value as the RMTC value.
            if title == "RMTC Achieved" and value in (None, ""):
                value = row.get("source_actual_value")
            line.append("-" if value in (None, "") else value)
        rows.append(line)
    first_width = 26 * mm
    remaining = max(1.0, content_width - first_width)
    value_width = remaining / max(1, len(header) - 1)
    widths = [first_width, *([value_width] * (len(header) - 1))]
    return _rmtc_grid(rows, widths, styles["header"], styles["small"], header_rows=1)


# Compatibility tokens retained for v4.12.5 verification: ["Final Decision", overall] and ["Decision Reason", decision_reason]

def _quality_conclusion_table(
    *,
    conclusion: object,
    conclusion_remark: object = None,
    final_decision: object,
    decision_reason: object,
    content_width: float,
    styles: Mapping[str, ParagraphStyle],
) -> Table:
    """High-visibility conclusion block used by MetLAB and inspection PDFs."""
    conclusion_style = ParagraphStyle(
        "QcConclusionValue", parent=styles["cell"], fontName="Helvetica-Bold",
        fontSize=6.6, leading=8.0, textColor=NAVY,
    )
    remark_style = ParagraphStyle(
        "QcConclusionRemark", parent=styles["cell"], fontName="Helvetica-Oblique",
        fontSize=5.8, leading=7.0, textColor=colors.HexColor("#7C2D12"),
    )
    decision_style = ParagraphStyle(
        "QcFinalDecision", parent=styles["cell"], fontName="Helvetica-Bold",
        fontSize=7.0, leading=8.2, textColor=TEXT,
    )
    rows: list[tuple[str, object, ParagraphStyle, colors.Color]] = [
        ("Conclusion", conclusion, conclusion_style, colors.HexColor("#E0F2FE")),
    ]
    if str(conclusion_remark or "").strip():
        rows.append(("Conclusion Remark", conclusion_remark, remark_style, colors.HexColor("#FFF7ED")))
    rows.extend([
        ("Final Decision", final_decision, decision_style, _table_status_color(final_decision)),
        ("Decision Reason", decision_reason, styles["cell"], colors.HexColor("#F8FAFC")),
    ])
    prepared = [[_paragraph(label, styles["label"]), _paragraph(_display_value(value), value_style)] for label, value, value_style, _ in rows]
    table = Table(prepared, colWidths=[36 * mm, content_width - 36 * mm], hAlign="LEFT", splitByRow=1)
    commands = [
        ("GRID", (0, 0), (-1, -1), 0.55, colors.HexColor("#64748B")),
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#E2E8F0")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 3.0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 3.0),
        ("TOPPADDING", (0, 0), (-1, -1), 3.0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3.0),
    ]
    for index, (_, _, _, background) in enumerate(rows):
        commands.append(("BACKGROUND", (1, index), (1, index), background))
    table.setStyle(TableStyle(commands))
    return table


def _fit_image_flowable(image_bytes: bytes, max_width: float, max_height: float) -> RLImage | None:
    if not image_bytes:
        return None
    try:
        with PILImage.open(BytesIO(image_bytes)) as image:
            width_px, height_px = image.size
        if width_px <= 0 or height_px <= 0:
            return None
        scale = min(max_width / float(width_px), max_height / float(height_px))
        return RLImage(BytesIO(image_bytes), width=width_px * scale, height=height_px * scale)
    except Exception:
        return None


def _microstructure_photo_table(items: list[Mapping[str, object]], content_width: float, caption_style: ParagraphStyle) -> Table:
    column_width = content_width / 3.0
    cells = []
    for slot in range(1, 4):
        item = next((dict(row) for row in items if int(row.get('slot') or 0) == slot), {})
        image = _fit_image_flowable(bytes(item.get('bytes') or b''), column_width - 5 * mm, 40 * mm)
        caption = _paragraph(item.get('caption') or f'Microstructure Photo {slot}', caption_style)
        if image is None:
            placeholder = Table(
                [[_paragraph('No photograph uploaded', caption_style)]],
                colWidths=[column_width - 6 * mm], rowHeights=[36 * mm],
            )
            placeholder.setStyle(TableStyle([
                ('BOX', (0, 0), (-1, -1), 0.5, BORDER),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F7FAFC')),
            ]))
            body = [placeholder, Spacer(1, 1 * mm), caption]
        else:
            body = [image, Spacer(1, 1 * mm), caption]
        cells.append(body)
    table = Table([cells], colWidths=[column_width] * 3, hAlign='LEFT')
    table.setStyle(TableStyle([
        ('BOX', (0, 0), (-1, -1), 0.55, BORDER),
        ('INNERGRID', (0, 0), (-1, -1), 0.35, BORDER),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('LEFTPADDING', (0, 0), (-1, -1), 2.5),
        ('RIGHTPADDING', (0, 0), (-1, -1), 2.5),
        ('TOPPADDING', (0, 0), (-1, -1), 3.0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3.0),
    ]))
    return table


def rmtc_record_pdf_bytes(payload: Mapping[str, object]) -> bytes:
    """Create a compact controlled RMTC Record PDF in A4 portrait orientation."""
    record = dict(payload.get("record") or {})
    part_approvals = [dict(row) for row in (payload.get("part_approvals") or [])]
    parts = dict(payload.get("parts") or {})
    grades = dict(payload.get("material_grades") or {})
    chemistry = [dict(row) for row in (payload.get("chemistry") or [])]
    jominy = [dict(row) for row in (payload.get("jominy") or [])]
    requirements = [dict(row) for row in (payload.get("requirements") or [])]
    supplier = dict(payload.get("supplier") or {})
    steel_mill = dict(payload.get("steel_mill") or {})
    employees = dict(payload.get("employees") or {})
    heat_summary = dict(payload.get("heat_summary") or {})
    heat_usage = [dict(row) for row in (payload.get("heat_usage") or [])]
    microstructure_images = [dict(row) for row in (payload.get("microstructure_images") or [])]

    buffer = BytesIO()
    title = f"RMTC RECORD - {record.get('rmtc_number') or 'QUALITY RECORD'}"
    page_width, page_height = A4
    edge = 8 * mm
    content_width = page_width - (2 * edge)
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=edge,
        rightMargin=edge,
        topMargin=30 * mm,
        bottomMargin=12 * mm,
        title=title,
        author="Four Star Industries - Quality Control Monitoring System",
        allowSplitting=1,
    )
    styles = getSampleStyleSheet()
    section_text_style = ParagraphStyle(
        "RmtcSectionText", parent=styles["Normal"], fontName="Helvetica-Bold",
        fontSize=7.1, leading=8.3, textColor=WHITE,
    )
    sub_text_style = ParagraphStyle(
        "RmtcSubText", parent=styles["Normal"], fontName="Helvetica-Bold",
        fontSize=6.3, leading=7.4, textColor=NAVY,
    )
    header_style = ParagraphStyle(
        "RmtcHeaderCell", parent=styles["Normal"], fontName="Helvetica-Bold",
        fontSize=4.9, leading=5.8, textColor=WHITE, alignment=TA_CENTER,
    )
    cell_style = ParagraphStyle(
        "RmtcCell", parent=styles["Normal"], fontName="Helvetica",
        fontSize=5.0, leading=5.9, textColor=TEXT, alignment=TA_LEFT,
    )
    label_style = ParagraphStyle(
        "RmtcLabel", parent=cell_style, fontName="Helvetica-Bold", textColor=NAVY,
    )
    center_style = ParagraphStyle(
        "RmtcCenter", parent=cell_style, alignment=TA_CENTER,
    )
    small_style = ParagraphStyle(
        "RmtcSmall", parent=cell_style, fontSize=4.6, leading=5.4,
    )

    story: list[object] = []

    # Header / traceability. The 4-column grid is exactly the same width as the page header.
    story.append(_rmtc_section_bar("RMTC HEADER & TRACEABILITY", content_width, section_text_style))
    header_pairs = [
        ("QCMS RMTC Number", record.get("rmtc_number"), "Entry Date", record.get("entry_date")),
        ("Supplier RMTC Number", record.get("certificate_reference"), "RMTC Date", record.get("certificate_date")),
        ("Supplier", supplier.get("party_name"), "Steel Mill", steel_mill.get("party_name")),
        ("Heat Number", record.get("heat_number"), "Internal Heat Code", record.get("heat_code")),
        ("Global Heat Steel Qty kg", record.get("certificate_quantity"), "RM Section", record.get("rm_section")),
        ("Forging Route / Root", record.get("forging_route"), "Prepared By", _employee_name(employees.get(str(record.get("prepared_by_employee_id"))))),
        ("Workflow Status", record.get("status"), "Validation Result", record.get("validation_result")),
        ("Final Disposition", record.get("disposition"), "Decision Date", record.get("decision_at")),
    ]
    story.append(_rmtc_labeled_grid(
        [list(row) for row in header_pairs],
        [29 * mm, 68 * mm, 29 * mm, 68 * mm],
        label_style, cell_style,
    ))
    if str(record.get("remarks") or "").strip():
        story.append(_rmtc_labeled_grid(
            [["RMTC Remarks", record.get("remarks")]],
            [29 * mm, content_width - 29 * mm], label_style, cell_style,
            label_columns=(0,),
        ))

    story.append(Spacer(1, 1.6 * mm))
    story.append(_rmtc_section_bar("GLOBAL HEAT QUANTITY BALANCE & RECORD LIST", content_width, section_text_style))
    heat_balance_rows = [
        ["Global Heat Qty kg", heat_summary.get("global_steel_quantity_kg") or record.get("certificate_quantity"),
         "Committed kg", heat_summary.get("committed_steel_quantity_kg"),
         "Unallocated Balance kg", heat_summary.get("available_unallocated_steel_quantity_kg") or heat_summary.get("available_steel_quantity_kg")],
        ["Inward Steel Used kg", heat_summary.get("inward_steel_quantity_kg"),
         "Remaining Planned kg", heat_summary.get("remaining_planned_steel_quantity_kg"),
         "Active RMTC Records", heat_summary.get("active_rmtc_count")],
    ]
    story.append(_rmtc_labeled_grid(
        heat_balance_rows,
        [31*mm, 33*mm, 31*mm, 33*mm, 34*mm, 32*mm],
        label_style, cell_style, label_columns=(0, 2, 4),
    ))
    heat_record_rows = [["RMTC No.", "Supplier RMTC", "Supplier", "Part", "Planned kg", "Inward kg", "Balance Plan kg", "Decision"]]
    for row in heat_usage:
        heat_record_rows.append([
            row.get("rmtc_number"), row.get("supplier_rmtc_number"), row.get("supplier_name"), row.get("part_number"),
            row.get("planned_steel_quantity_kg"), row.get("inward_steel_quantity_kg"), row.get("remaining_planned_steel_quantity_kg"),
            row.get("part_disposition") or row.get("rmtc_disposition") or row.get("rmtc_status"),
        ])
    if len(heat_record_rows) == 1:
        heat_record_rows.append([record.get("rmtc_number"), record.get("certificate_reference"), supplier.get("party_name"), "-", "-", "-", "-", record.get("disposition") or record.get("status")])
    story.append(_rmtc_grid(
        heat_record_rows,
        [24*mm, 27*mm, 34*mm, 21*mm, 21*mm, 21*mm, 25*mm, 21*mm],
        header_style, small_style, status_columns=(7,),
    ))

    story.append(Spacer(1, 1.6 * mm))
    story.append(_rmtc_section_bar("COVERED PART WORKSHEET REGISTER", content_width, section_text_style))
    part_summary = [[
        "Part No.", "FSI Part No.", "Description", "Grade", "Planned Qty", "Input kg", "Steel kg", "Worksheet", "Auto Validation", "Final Decision",
    ]]
    for approval in part_approvals:
        part = parts.get(str(approval.get("part_id"))) or {}
        grade = grades.get(str(part.get("material_grade_id"))) or {}
        part_summary.append([
            part.get("part_number"), part.get("fsi_part_number"), part.get("part_name"), grade.get("grade_code") or grade.get("grade_name"),
            approval.get("planned_production_quantity_pcs"), approval.get("input_weight_kg"), approval.get("planned_steel_quantity_kg"),
            "Completed" if approval.get("worksheet_completed_at") else "Pending",
            approval.get("approval_status") or "NOT_EVALUATED", approval.get("disposition") or "PENDING",
        ])
    if len(part_summary) == 1:
        part_summary.append(["-", "-", "No covered part worksheets found", "", "", "", "", "Pending", "NOT_EVALUATED", "PENDING"])
    story.append(_rmtc_grid(
        part_summary,
        [17*mm, 20*mm, 27*mm, 17*mm, 16*mm, 17*mm, 18*mm, 20*mm, 21*mm, 21*mm],
        header_style, small_style, status_columns=(7, 8, 9),
    ))

    mechanical = record.get("mechanical_results") or {}
    story.append(Spacer(1, 1.6 * mm))
    story.append(_rmtc_section_bar("SUPPLIER RMTC MECHANICAL PROPERTIES", content_width, section_text_style))
    mech_rows = [["Property", "Actual / Result", "Source"]]
    if isinstance(mechanical, Mapping) and mechanical:
        for key, value in mechanical.items():
            mech_rows.append([str(key).replace("_", " ").title(), value, "Supplier RMTC"])
    else:
        mech_rows.append(["Mechanical Properties", "No dedicated mechanical property values recorded", "Supplier RMTC"])
    story.append(_rmtc_grid(mech_rows, [55*mm, 94*mm, 45*mm], header_style, cell_style))

    # Worksheets flow continuously. No forced page break is used, reducing total pages.
    for worksheet_index, approval in enumerate(part_approvals, start=1):
        story.append(CondPageBreak(42 * mm))
        part_id = str(approval.get("part_id") or "")
        part = parts.get(part_id) or {}
        grade = grades.get(str(part.get("material_grade_id"))) or {}
        part_title = f"PART WORKSHEET {worksheet_index} - {part.get('part_number') or '-'} - {part.get('part_name') or ''}"
        story.append(_rmtc_section_bar(part_title, content_width, section_text_style))

        identity_rows = [
            ["Part Number", part.get("part_number"), "FSI Part Number", part.get("fsi_part_number"), "Part Description", part.get("part_name")],
            ["Material Grade", grade.get("grade_code") or grade.get("grade_name"), "Heat Number", record.get("heat_number"), "Heat Code", record.get("heat_code")],
            ["Worksheet Status", "Completed" if approval.get("worksheet_completed_at") else "Pending", "", "", "", ""],
            ["Planned Production Qty pcs", approval.get("planned_production_quantity_pcs"), "Input Weight kg", approval.get("input_weight_kg"), "Planned Steel kg", approval.get("planned_steel_quantity_kg")],
        ]
        story.append(_rmtc_labeled_grid(
            identity_rows,
            [25*mm, 37*mm, 27*mm, 43*mm, 27*mm, 35*mm],
            label_style, cell_style,
            label_columns=(0, 2, 4),
        ))

        part_chem = [row for row in chemistry if str(row.get("part_id")) == part_id]
        story.append(_rmtc_section_bar("Chemical Composition", content_width, sub_text_style, light=True))
        chem_rows = [["Element", "Minimum", "Maximum", "Actual", "Unit", "Status"]]
        for row in part_chem:
            chem_rows.append([row.get("element"), row.get("minimum_value"), row.get("maximum_value"), row.get("actual_value"), row.get("unit") or "%", row.get("result")])
        if len(chem_rows) == 1:
            chem_rows.append(["-", "", "", "No chemistry values recorded", "", "NOT_EVALUATED"])
        story.append(_rmtc_grid(chem_rows, [24*mm, 31*mm, 31*mm, 39*mm, 19*mm, 50*mm], header_style, cell_style, status_columns=(5,)))

        part_jominy = [row for row in jominy if str(row.get("part_id")) == part_id]
        story.append(_rmtc_section_bar("Jominy Results", content_width, sub_text_style, light=True))
        j_rows = [["Distance", "mm", "Min HRC", "Max HRC", "Actual", "Actual Status", "Calculated", "Calc. Status", "Applicable"]]
        for row in part_jominy:
            j_rows.append([
                row.get("distance_label"), row.get("distance_mm"), row.get("minimum_hrc"), row.get("maximum_hrc"),
                row.get("actual_hrc"), row.get("result"), row.get("calculated_hrc"), row.get("calculated_result"),
                "No" if str(row.get("applicability")) == "NOT_APPLICABLE" else "Yes",
            ])
        if len(j_rows) == 1:
            j_rows.append(["-", "", "", "", "", "NOT_EVALUATED", "", "NOT_EVALUATED", "No"])
        story.append(_rmtc_grid(
            j_rows,
            [20*mm, 14*mm, 18*mm, 18*mm, 20*mm, 24*mm, 22*mm, 28*mm, 30*mm],
            header_style, small_style, status_columns=(5, 7),
        ))

        story.append(_rmtc_section_bar("DI / Hardenability", content_width, sub_text_style, light=True))
        di_rows = [["Grain Size ASTM E-112", "Actual DI", "Actual DI Status", "Calculated DI", "Calculated DI Status"]]
        di_rows.append([approval.get("grain_size"), approval.get("actual_di"), approval.get("actual_di_status"), approval.get("calculated_di"), approval.get("calculated_di_status")])
        story.append(_rmtc_grid(di_rows, [42*mm, 32*mm, 42*mm, 32*mm, 46*mm], header_style, cell_style, status_columns=(2, 4)))

        part_req = [row for row in requirements if str(row.get("part_id")) == part_id]
        mechanical_tokens = ("tensile", "yield", "elongation", "reduction", "impact", "proof", "mechanical", "uts")
        mech_req = [row for row in part_req if any(token in str(row.get("requirement_name") or row.get("requirement_code") or "").casefold() for token in mechanical_tokens)]
        other_req = [row for row in part_req if row not in mech_req]

        story.append(_rmtc_section_bar("Mechanical Properties", content_width, sub_text_style, light=True))
        mech_part_rows = [["Property", "Specification", "Actual / Observation", "Unit", "Status", "Remarks"]]
        for row in mech_req:
            mech_part_rows.append([row.get("requirement_name") or row.get("requirement_code"), row.get("requirement_value"), row.get("actual_value"), row.get("unit"), row.get("result"), row.get("remarks")])
        if len(mech_part_rows) == 1:
            mech_part_rows.append(["Mechanical Properties", "As supplier RMTC / Part requirement", "No separate part-level mechanical property row", "", "NOT_EVALUATED", ""])
        story.append(_rmtc_grid(mech_part_rows, [38*mm, 42*mm, 40*mm, 18*mm, 24*mm, 32*mm], header_style, small_style, status_columns=(4,)))

        story.append(_rmtc_section_bar("Heat Treatment & Other Requirements", content_width, sub_text_style, light=True))
        req_rows = [["Requirement", "Specification / Part Master", "RMTC Actual / Observation", "Unit", "Status", "Remarks"]]
        for row in other_req:
            req_rows.append([row.get("requirement_name") or row.get("requirement_code"), row.get("requirement_value"), row.get("actual_value"), row.get("unit"), row.get("result"), row.get("remarks")])
        if len(req_rows) == 1:
            req_rows.append(["-", "No additional requirements recorded", "", "", "NOT_EVALUATED", ""])
        story.append(_rmtc_grid(req_rows, [38*mm, 45*mm, 39*mm, 18*mm, 24*mm, 30*mm], header_style, small_style, status_columns=(4,)))

    story.append(CondPageBreak(55 * mm))
    story.append(_rmtc_section_bar("RMTC MICROSTRUCTURE PHOTOGRAPHS", content_width, section_text_style))
    story.append(_microstructure_photo_table(microstructure_images, content_width, center_style))

    story.append(CondPageBreak(44 * mm))
    story.append(_rmtc_section_bar("RMTC VALIDATION STATUS & FINAL DECISION", content_width, section_text_style))
    if not part_approvals:
        story.append(_rmtc_grid(
            [["Validation Check", "Status", "Validation Check", "Status"], ["Record", "NOT_EVALUATED", "Final Decision", "PENDING"]],
            [42*mm, 55*mm, 42*mm, 55*mm], header_style, cell_style, status_columns=(1, 3),
        ))
    else:
        for approval_index, approval in enumerate(part_approvals, start=1):
            part = parts.get(str(approval.get("part_id"))) or {}
            grade = grades.get(str(part.get("material_grade_id"))) or {}
            if approval_index > 1:
                story.append(Spacer(1, 1.2 * mm))
            story.append(_rmtc_section_bar(
                f"{part.get('part_number') or '-'} - {part.get('part_name') or ''} - {grade.get('grade_code') or grade.get('grade_name') or ''}",
                content_width, sub_text_style, light=True,
            ))
            validation_rows = [["Validation Check", "Status", "Validation Check", "Status"],
                ["Source", approval.get("source_status"), "Material Grade", approval.get("material_grade_status")],
                ["Raw Material", approval.get("raw_material_status"), "Chemistry", approval.get("chemistry_status")],
                ["Jominy", approval.get("jominy_status"), "Requirements", approval.get("requirement_status")],
                ["Actual DI", approval.get("actual_di_status"), "Calculated DI", approval.get("calculated_di_status")],
                ["Automated Recommendation", approval.get("approval_status"), "Final Decision", approval.get("disposition")],
            ]
            story.append(_rmtc_grid(
                validation_rows, [42*mm, 55*mm, 42*mm, 55*mm],
                header_style, cell_style, status_columns=(1, 3),
            ))
            reason = approval.get("decision_reason") or record.get("decision_reason") or ""
            story.append(_rmtc_labeled_grid(
                [["Decision / Reserve Reason", reason or "-"]],
                [42*mm, 152*mm], label_style, cell_style, label_columns=(0,),
            ))

    story.append(Spacer(1, 1.6 * mm))
    sign_rows = [[
        "Prepared By", _employee_name(employees.get(str(record.get("prepared_by_employee_id")))),
        "Validated By", _employee_name(employees.get(str(record.get("validated_by_employee_id")))),
        "Approved / Decided By", _employee_name(employees.get(str(record.get("approved_by_employee_id") or record.get("decision_by_employee_id")))),
    ], [
        "Prepared At", _display_value(record.get("prepared_at")),
        "Validated At", _display_value(record.get("validated_at")),
        "Decision At", _display_value(record.get("decision_at") or record.get("approved_at")),
    ]]
    story.append(_rmtc_labeled_grid(
        sign_rows,
        [24*mm, 41*mm, 24*mm, 41*mm, 30*mm, 34*mm],
        label_style, center_style, label_columns=(0, 2, 4),
    ))

    doc.build(
        story,
        canvasmaker=lambda *args, **kwargs: _PageNumberCanvas(
            *args, report_title=title,
            heat_number=str(record.get("heat_number") or ""),
            record_number=str(record.get("rmtc_number") or ""),
            report_label="RMTC RECORD",
            **kwargs,
        ),
    )
    return buffer.getvalue()


def _photo_grid_table(
    items: list[Mapping[str, object]],
    content_width: float,
    caption_style: ParagraphStyle,
    *,
    columns: int = 2,
    max_height: float = 46 * mm,
) -> Table:
    columns = max(1, int(columns))
    col_width = content_width / columns
    normalized = [dict(item) for item in items] or []
    cells: list[list[object]] = []
    for index, item in enumerate(normalized, start=1):
        image = _fit_image_flowable(bytes(item.get("bytes") or b""), col_width - 6 * mm, max_height)
        caption = _paragraph(item.get("caption") or f"Microstructure Photo {index}", caption_style)
        if image is None:
            placeholder = Table(
                [[_paragraph("No photograph uploaded", caption_style)]],
                colWidths=[col_width - 8 * mm], rowHeights=[max_height - 5 * mm],
            )
            placeholder.setStyle(TableStyle([
                ("BOX", (0, 0), (-1, -1), 0.5, BORDER),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F7FAFC")),
            ]))
            cell = [placeholder, Spacer(1, 1 * mm), caption]
        else:
            cell = [image, Spacer(1, 1 * mm), caption]
        if (index - 1) % columns == 0:
            cells.append([])
        cells[-1].append(cell)
    if not cells:
        cells = [[[_paragraph("No microstructure photographs recorded", caption_style)]]]
        columns = 1
        col_width = content_width
    while len(cells[-1]) < columns:
        cells[-1].append("")
    table = Table(cells, colWidths=[col_width] * columns, hAlign="LEFT")
    table.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.55, BORDER),
        ("INNERGRID", (0, 0), (-1, -1), 0.35, BORDER),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("LEFTPADDING", (0, 0), (-1, -1), 3),
        ("RIGHTPADDING", (0, 0), (-1, -1), 3),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    return table


def _controlled_styles() -> dict[str, ParagraphStyle]:
    styles = getSampleStyleSheet()
    cell = ParagraphStyle("QcCell", parent=styles["Normal"], fontName="Helvetica", fontSize=5.4, leading=6.4, textColor=TEXT)
    return {
        "section": ParagraphStyle("QcSection", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=7.2, leading=8.4, textColor=WHITE),
        "sub": ParagraphStyle("QcSub", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=6.5, leading=7.6, textColor=NAVY),
        "header": ParagraphStyle("QcHeader", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=5.2, leading=6.1, textColor=WHITE, alignment=TA_CENTER),
        "cell": cell,
        "small": ParagraphStyle("QcSmall", parent=cell, fontSize=4.8, leading=5.6),
        "label": ParagraphStyle("QcLabel", parent=cell, fontName="Helvetica-Bold", textColor=NAVY),
        "center": ParagraphStyle("QcCenter", parent=cell, alignment=TA_CENTER),
    }




def _case_depth_chart(locations: list[dict], traverse: list[dict], width: float, height: float = 58 * mm) -> Drawing | None:
    names = [str(row.get("location") or row.get("name") or "").strip() for row in locations]
    names = [name for name in names if name]
    if not names or not traverse:
        return None
    series = []
    active_names = []
    all_values: list[float] = []
    all_distances: list[float] = []
    for name in names:
        points = []
        for row in traverse:
            try:
                distance = float(row.get("distance_mm"))
            except (TypeError, ValueError):
                continue
            value = (row.get("readings") or {}).get(name)
            try:
                numeric = float(value)
            except (TypeError, ValueError):
                continue
            points.append((distance, numeric)); all_values.append(numeric); all_distances.append(distance)
        if points:
            series.append(points); active_names.append(name)
    if not series:
        return None

    drawing = Drawing(width, height)
    plot = LinePlot()
    plot.x = 36
    plot.y = 22
    plot.width = max(80, width - 128)
    plot.height = max(70, height - 38)
    plot.data = series
    palette = [NAVY, BLUE, colors.HexColor("#2E8B57"), colors.HexColor("#7B3FB8"), colors.HexColor("#C55A11"), colors.HexColor("#5B6573")]
    for index, _name in enumerate(active_names):
        line = plot.lines[index]
        line.strokeColor = palette[index % len(palette)]
        line.strokeWidth = 1.3
        line.symbol = makeMarker("FilledCircle")
        line.symbol.size = 3.5
        line.symbol.fillColor = palette[index % len(palette)]
        line.symbol.strokeColor = palette[index % len(palette)]
    min_x, max_x = min(all_distances), max(all_distances)
    plot.xValueAxis.valueMin = max(0.0, min_x)
    plot.xValueAxis.valueMax = max_x if max_x > min_x else min_x + 0.1
    plot.xValueAxis.valueStep = 0.1 if plot.xValueAxis.valueMax <= 2 else None
    min_y, max_y = min(all_values), max(all_values)
    padding = max(20.0, (max_y - min_y) * 0.1)
    plot.yValueAxis.valueMin = max(0.0, min_y - padding)
    plot.yValueAxis.valueMax = max_y + padding
    plot.xValueAxis.labelTextFormat = "%.2f"
    plot.yValueAxis.labelTextFormat = "%d"
    drawing.add(plot)
    drawing.add(String(plot.x + plot.width / 2, 2, "Distance (mm)", fontName="Helvetica-Bold", fontSize=6, fillColor=TEXT, textAnchor="middle"))
    drawing.add(String(2, height - 12, "Hardness (HV)", fontName="Helvetica-Bold", fontSize=6, fillColor=TEXT))
    legend = Legend()
    legend.x = width - 86
    legend.y = height - 18
    legend.fontName = "Helvetica"
    legend.fontSize = 5.5
    legend.dx = 8
    legend.dy = 6
    legend.deltay = 8
    legend.colorNamePairs = [(palette[i % len(palette)], name) for i, name in enumerate(active_names)]
    drawing.add(legend)
    return drawing

def metlab_record_pdf_bytes(payload: Mapping[str, object]) -> bytes:
    """Controlled A4 portrait MetLAB report for Material Inward and OSP modules."""
    record = dict(payload.get("record") or {})
    part = dict(payload.get("part") or {})
    inward = dict(payload.get("inward") or {})
    supplier = dict(payload.get("supplier") or {})
    osp_vendor = dict(payload.get("osp_vendor") or {})
    osp_vendor_name = osp_vendor.get("party_name") or (dict(payload.get("osp_job") or {}).get("vendor_name")) or "-"
    steel_mill = dict(payload.get("steel_mill") or {})
    grade = dict(payload.get("material_grade") or {})
    customer = dict(payload.get("customer") or {})
    process = dict(payload.get("process") or {})
    stage = dict(payload.get("stage") or {})
    osp_job = dict(payload.get("osp_job") or {})
    employees = dict(payload.get("employees") or {})
    results = dict(payload.get("results") or {})
    microstructure_images = [dict(row) for row in (payload.get("microstructure_images") or [])]
    inspection_method = str(results.get("inspection_method") or "GENERAL_METLAB").strip().upper()
    is_bend_test = inspection_method == "BEND_TEST"

    scope = str(record.get("inspection_scope") or "MATERIAL_INWARD")
    is_osp = scope.startswith("OSP_") or scope == "OSP_STAGE" or bool(record.get("osp_job_id"))
    title = (
        "BEND TEST REPORT" if is_bend_test else
        "OSP METALLURGICAL TEST REPORT" if is_osp else
        "FINAL METALLURGICAL TEST REPORT" if scope == "FINAL_DISPATCH_STAGE" else
        "RAW MATERIAL METALLURGICAL TEST REPORT"
    )
    buffer = BytesIO()
    page_width, _ = A4
    edge = 8 * mm
    content_width = page_width - 2 * edge
    doc = SimpleDocTemplate(
        buffer, pagesize=A4, leftMargin=edge, rightMargin=edge, topMargin=30 * mm, bottomMargin=12 * mm,
        title=title, author="Four Star Industries - Quality Control Monitoring System", allowSplitting=1,
    )
    sty = _controlled_styles()
    story: list[object] = []

    story.append(_rmtc_section_bar(title, content_width, sty["section"]))
    vendor_or_supplier = osp_job.get("vendor_name") if is_osp else supplier.get("party_name")
    supply_condition = osp_job.get("process_name") or process.get("process_name") or record.get("layout_name_snapshot")
    qty = osp_job.get("sample_quantity") if scope == "OSP_SAMPLE" else (osp_job.get("quantity_received") if is_osp else record.get("production_quantity_pcs"))
    meta = [
        ["Report No.", record.get("report_number"), "Date", record.get("test_date")],
        ["Part Name", part.get("part_name"), "Part No.", part.get("part_number")],
        ["Customer", customer.get("party_name"), "Supplier", supplier.get("party_name")],
        ["OSP Vendor", osp_vendor_name, "Material Used", grade.get("grade_code") or grade.get("grade_name")],
        ["Supply / Process Condition", record.get("supply_condition") or supply_condition, "Process", process.get("process_name") or record.get("process_specification_snapshot")],
        ["Supplier Invoice / Reference", record.get("supplier_reference_number"), "Quantity (pcs)", record.get("production_quantity_pcs") or qty],
        ["Heat Number", record.get("heat_number") or inward.get("heat_number") or osp_job.get("heat_number"), "Heat Code", record.get("heat_code") or inward.get("heat_code")],
        ["Supplier / HT / OSP Batch", record.get("vendor_batch_number_snapshot") or osp_job.get("vendor_batch_number"), "Internal / FSI Batch", record.get("batch_number")],
        ["Inspection Stage", stage.get("stage_name") or scope.replace("_", " ").title(), "Process", process.get("process_name") or record.get("process_specification_snapshot")],
        ["Drawing / Revision", f"{part.get('drawing_number') or '-'} / {part.get('drawing_revision') or '-'}", "Specification Reference", record.get("specification_reference")],
        ["Sample / Reference", record.get("reference_text") or record.get("sample_reference") or inward.get("inward_number") or osp_job.get("sample_reference"), "Report Layout", record.get("layout_name_snapshot")],
    ]
    story.append(_rmtc_labeled_grid(meta, [32*mm, 65*mm, 32*mm, 65*mm], sty["label"], sty["cell"], label_columns=(0, 2)))

    section_rows = [dict(row) for row in (results.get("rows") or [])]
    requirement_rows = [dict(row) for row in (results.get("requirement_rows") or [])]
    test_rows = [["Sr.", "Parameter", "Specification", "Observations", "Unit", "Result"]]
    sequence = 1
    for row in section_rows:
        spec = row.get("specification")
        if not spec:
            lo, hi = row.get("lower_spec"), row.get("upper_spec")
            if lo is not None or hi is not None:
                spec = f"{'' if lo is None else lo} - {'' if hi is None else hi}".strip(" -")
        test_rows.append([row.get("sequence_no") or sequence, row.get("parameter"), spec, row.get("actual_value"), row.get("unit"), row.get("result")])
        sequence += 1
    for row in requirement_rows:
        test_rows.append([sequence, row.get("requirement_name"), row.get("requirement_value"), row.get("actual_value"), row.get("unit"), row.get("result")])
        sequence += 1
    if len(test_rows) == 1:
        test_rows.append([1, "Metallurgical requirements", "As approved inspection layout", "No result rows recorded", "", "NOT_EVALUATED"])
    story.append(Spacer(1, 1.4 * mm))
    if is_bend_test:
        baking_keywords = ("baking", "base metal hardness")
        baking_rows = [test_rows[0]] + [row for row in test_rows[1:] if any(token in str(row[1] or "").casefold() for token in baking_keywords)]
        bend_rows = [test_rows[0]] + [row for row in test_rows[1:] if not any(token in str(row[1] or "").casefold() for token in baking_keywords)]
        if len(baking_rows) > 1:
            story.append(_rmtc_section_bar("BAKING / AGING", content_width, sty["section"]))
            story.append(_rmtc_grid(baking_rows, [12*mm, 54*mm, 50*mm, 46*mm, 14*mm, 18*mm], sty["header"], sty["small"], status_columns=(5,)))
            story.append(Spacer(1, 1.2 * mm))
        story.append(_rmtc_section_bar("BEND TEST RESULTS", content_width, sty["section"]))
        story.append(_rmtc_grid(bend_rows if len(bend_rows) > 1 else test_rows, [12*mm, 54*mm, 50*mm, 46*mm, 14*mm, 18*mm], sty["header"], sty["small"], status_columns=(5,)))
    else:
        story.append(_rmtc_section_bar("METALLURGICAL TEST RESULTS", content_width, sty["section"]))
        story.append(_rmtc_grid(test_rows, [12*mm, 54*mm, 50*mm, 46*mm, 14*mm, 18*mm], sty["header"], sty["small"], status_columns=(5,)))

    case_locations = [dict(row) for row in (results.get("case_depth_locations") or [])]
    case_traverse = [dict(row) for row in (results.get("case_depth_traverse") or [])]
    if bool(results.get("case_depth_applicable")) and case_locations and case_traverse:
        location_names = [str(row.get("location") or row.get("name") or "").strip() for row in case_locations if str(row.get("location") or row.get("name") or "").strip()]
        story.append(Spacer(1, 1.4 * mm))
        story.append(_rmtc_section_bar("CASE DEPTH / MICROHARDNESS TRAVERSE", content_width, sty["section"]))
        location_specs = [["Location", "Controlled Parameter", "Specification", "Unit"]]
        for row in case_locations:
            location_specs.append([
                row.get("location") or row.get("name"),
                row.get("parameter") or "Case Depth",
                row.get("specification") or "-",
                row.get("unit") or "",
            ])
        story.append(_rmtc_grid(location_specs, [34*mm, 66*mm, 72*mm, 22*mm], sty["header"], sty["small"]))
        story.append(Spacer(1, 1.0 * mm))
        table_rows = [["Distance (mm)", *location_names]]
        for row in case_traverse:
            readings = dict(row.get("readings") or {})
            table_rows.append([row.get("distance_mm"), *[readings.get(name) for name in location_names]])
        widths = [28 * mm] + [(content_width - 28 * mm) / max(1, len(location_names))] * len(location_names)
        story.append(_rmtc_grid(table_rows, widths, sty["header"], sty["small"]))
        chart = _case_depth_chart(case_locations, case_traverse, content_width)
        if chart is not None:
            story.append(Spacer(1, 1.2 * mm))
            story.append(_rmtc_section_bar("CASE DEPTH TRAVERSE · Distance (mm) vs Hardness (HV)", content_width, sty["sub"], light=True))
            story.append(chart)
    elif results.get("case_depth_na_reason"):
        story.append(_rmtc_section_bar("CASE DEPTH / MICROHARDNESS TRAVERSE", content_width, sty["sub"], light=True))
        story.append(Paragraph(f"Not Applicable: {results.get('case_depth_na_reason')}", sty["cell"]))

    chemistry_rows = [dict(row) for row in (results.get("chemistry_rows") or [])]
    if chemistry_rows:
        story.append(_rmtc_section_bar("CHEMICAL ANALYSIS · ASTM E 415 / IS 8811", content_width, sty["sub"], light=True))
        story.append(_chemical_horizontal_report_table(chemistry_rows, content_width, sty))

    jominy_rows = [dict(row) for row in (results.get("jominy_rows") or [])]
    if jominy_rows:
        story.append(_rmtc_section_bar("HARDNESS / JOMINY TRAVERSE", content_width, sty["sub"], light=True))
        rows = [["Distance", "mm", "Min HRC", "Max HRC", "RMTC HRC", "MetLAB HRC", "Result", "Remark"]]
        for row in jominy_rows:
            rows.append([row.get("distance_label"), row.get("distance_mm"), row.get("minimum_hrc"), row.get("maximum_hrc"), row.get("rmtc_actual_hrc"), row.get("actual_value"), row.get("result"), row.get("remarks")])
        story.append(_rmtc_grid(rows, [20*mm, 17*mm, 22*mm, 22*mm, 25*mm, 28*mm, 22*mm, 38*mm], sty["header"], sty["small"], status_columns=(6,)))

    story.append(CondPageBreak(70 * mm))
    evidence_title = "BEND TEST EVIDENCE / PART PHOTOGRAPHS" if is_bend_test else "MICROSTRUCTURE PHOTOGRAPHS"
    story.append(_rmtc_section_bar(evidence_title, content_width, sty["section"]))
    story.append(_photo_grid_table(microstructure_images, content_width, sty["center"], columns=2, max_height=46*mm))

    reference_documents = [str(value).strip() for value in (results.get("reference_documents") or []) if str(value).strip()]
    if reference_documents:
        story.append(Spacer(1, 1.2 * mm))
        story.append(_rmtc_section_bar("REFERENCE DOCUMENTS / STATEMENTS", content_width, sty["sub"], light=True))
        ref_rows = [["Sr.", "Reference"]] + [[index, value] for index, value in enumerate(reference_documents, start=1)]
        story.append(_rmtc_grid(ref_rows, [14*mm, content_width - 14*mm], sty["header"], sty["small"]))

    prepared = _employee_name(employees.get(str(record.get("prepared_by_employee_id"))))
    validated = _employee_name(employees.get(str(record.get("validated_by_employee_id"))))
    approved = _employee_name(employees.get(str(record.get("approved_by_employee_id"))))
    overall = record.get("disposition") or record.get("overall_result") or "NOT_EVALUATED"
    conclusion = record.get("remarks") or f"Overall result: {record.get('overall_result') or overall}"
    decision_reason = record.get("disposition_reason") or "-"
    conclusion_remark = results.get("conclusion_remark")
    story.append(Spacer(1, 1.5 * mm))
    story.append(_quality_conclusion_table(
        conclusion=conclusion, conclusion_remark=conclusion_remark, final_decision=overall,
        decision_reason=decision_reason, content_width=content_width, styles=sty,
    ))
    story.append(_rmtc_labeled_grid([
        ["Prepared By", prepared, "Validated By", validated, "Verified & Approved By", approved],
        ["Prepared / Test Date", record.get("test_date"), "Validated At", record.get("validated_at"), "Decision At", record.get("decision_at")],
    ], [25*mm, 37*mm, 25*mm, 37*mm, 34*mm, 36*mm], sty["label"], sty["center"], label_columns=(0, 2, 4)))

    doc.build(story, canvasmaker=lambda *args, **kwargs: _PageNumberCanvas(*args, report_title=title, **kwargs))
    return buffer.getvalue()


def dimensional_record_pdf_bytes(payload: Mapping[str, object]) -> bytes:
    """A4 portrait Final / Dimensional Inspection report using the controlled report layout."""
    record = dict(payload.get("record") or {})
    part = dict(payload.get("part") or {})
    inward = dict(payload.get("inward") or {})
    supplier = dict(payload.get("supplier") or {})
    customer = dict(payload.get("customer") or {})
    grade = dict(payload.get("material_grade") or {})
    process = dict(payload.get("process") or {})
    stage = dict(payload.get("stage") or {})
    osp_job = dict(payload.get("osp_job") or {})
    employees = dict(payload.get("employees") or {})
    results = [dict(row) for row in (payload.get("results") or [])]
    scope = str(record.get("inspection_scope") or "MATERIAL_INWARD")
    is_osp = scope.startswith("OSP_") or scope == "OSP_STAGE" or bool(record.get("osp_job_id"))
    title = (
        "OSP DIMENSIONAL INSPECTION REPORT" if is_osp else
        "RAW MATERIAL DIMENSIONAL INSPECTION REPORT" if scope == "RAW_MATERIAL_STAGE" else
        "FINAL INSPECTION / DIMENSIONAL REPORT"
    )
    buffer = BytesIO(); page_width, _ = A4; edge = 8*mm; content_width = page_width - 2*edge
    doc = SimpleDocTemplate(buffer, pagesize=A4, leftMargin=edge, rightMargin=edge, topMargin=30*mm, bottomMargin=12*mm, title=title, author="Four Star Industries - Quality Control Monitoring System", allowSplitting=1)
    sty = _controlled_styles(); story: list[object] = []
    story.append(_rmtc_section_bar(title, content_width, sty["section"]))
    meta = [
        ["Report No.", record.get("report_number"), "Date", record.get("inspection_date")],
        ["Part Name", part.get("part_name"), "Part No.", part.get("part_number")],
        ["Customer", customer.get("party_name"), "Supplier / OSP Vendor", osp_job.get("vendor_name") or supplier.get("party_name")],
        ["Material Grade", grade.get("grade_code") or grade.get("grade_name"), "Supply / Process Condition", record.get("supply_condition") or osp_job.get("process_name") or process.get("process_name")],
        ["Heat Number", record.get("heat_number") or inward.get("heat_number") or osp_job.get("heat_number"), "Heat Code", record.get("heat_code") or inward.get("heat_code")],
        ["Supplier / HT / OSP Batch", record.get("vendor_batch_number_snapshot") or osp_job.get("vendor_batch_number"), "Internal / FSI Batch", record.get("batch_number")],
        ["Supplier Invoice / Reference", record.get("supplier_reference_number"), "Inspection Stage", stage.get("stage_name") or record.get("layout_type_name")],
        ["Drawing", record.get("drawing_number") or part.get("drawing_number"), "Revision", record.get("drawing_revision") or part.get("drawing_revision")],
        ["Process", osp_job.get("process_name") or process.get("process_name") or record.get("process_specification_snapshot"), "Layout", record.get("layout_name_snapshot")],
        ["Lot / Production Qty", record.get("production_quantity_pcs") or record.get("lot_quantity"), "Sample Size", record.get("sample_size")],
        ["Sample / Lot Reference", record.get("reference_text"), "Report Scope", scope.replace("_", " ").title()],
    ]
    story.append(_rmtc_labeled_grid(meta, [32*mm,65*mm,32*mm,65*mm], sty["label"], sty["cell"], label_columns=(0,2)))
    story.append(Spacer(1,1.5*mm)); story.append(_rmtc_section_bar("INSPECTION RESULTS", content_width, sty["section"]))
    rows = [["Sr.", "Parameter / Characteristic", "Specification", "Observations", "Method / Aid", "Result"]]
    for index, row in enumerate(results, start=1):
        observations = row.get("observations") or []
        if isinstance(observations, list): observations = ", ".join(str(v) for v in observations if v not in (None, ""))
        specification = row.get("specification")
        if not specification and (row.get("lower_spec") is not None or row.get("upper_spec") is not None):
            specification = f"{row.get('lower_spec') if row.get('lower_spec') is not None else ''} - {row.get('upper_spec') if row.get('upper_spec') is not None else ''} {row.get('unit') or ''}".strip()
        rows.append([row.get("sequence_no") or row.get("characteristic_no") or index, row.get("characteristic"), specification, observations or row.get("attribute_result"), row.get("checking_aid"), row.get("result")])
    if len(rows)==1: rows.append([1,"Inspection characteristic","As approved layout","No results recorded","","NOT_EVALUATED"])
    story.append(_rmtc_grid(rows, [12*mm,54*mm,48*mm,42*mm,22*mm,16*mm], sty["header"], sty["small"], status_columns=(5,)))
    overall = record.get("disposition") or record.get("overall_result") or "NOT_EVALUATED"
    conclusion = record.get("remarks") or f"Overall result: {record.get('overall_result') or overall}"
    decision_reason = record.get("disposition_reason") or "-"
    story.append(Spacer(1,1.5*mm)); story.append(_quality_conclusion_table(
        conclusion=conclusion, conclusion_remark=None, final_decision=overall,
        decision_reason=decision_reason, content_width=content_width, styles=sty,
    ))
    story.append(_rmtc_labeled_grid([["Prepared By",_employee_name(employees.get(str(record.get("prepared_by_employee_id")))),"Validated By",_employee_name(employees.get(str(record.get("validated_by_employee_id")))),"Approved By",_employee_name(employees.get(str(record.get("approved_by_employee_id"))))]], [25*mm,39*mm,25*mm,39*mm,25*mm,41*mm], sty["label"], sty["center"], label_columns=(0,2,4)))
    doc.build(story, canvasmaker=lambda *args, **kwargs: _PageNumberCanvas(*args, report_title=title, **kwargs))
    return buffer.getvalue()


def material_inward_record_pdf_bytes(payload: Mapping[str, object]) -> bytes:
    """Controlled A4 portrait Material Inward quality record."""
    record = dict(payload.get("record") or {})
    register = dict(payload.get("register") or {})
    part = dict(payload.get("part") or {})
    supplier = dict(payload.get("supplier") or {})
    rmtc = dict(payload.get("rmtc") or {})
    employees = dict(payload.get("employees") or {})
    metlab = dict(payload.get("metlab") or {})
    dimensional = dict(payload.get("dimensional") or {})
    title = "MATERIAL INWARD INSPECTION RECORD"
    buffer=BytesIO(); page_width,_=A4; edge=8*mm; content_width=page_width-2*edge
    doc=SimpleDocTemplate(buffer,pagesize=A4,leftMargin=edge,rightMargin=edge,topMargin=30*mm,bottomMargin=12*mm,title=title,author="Four Star Industries - Quality Control Monitoring System",allowSplitting=1)
    sty=_controlled_styles(); story:list[object]=[]
    story.append(_rmtc_section_bar(title,content_width,sty["section"]))
    meta=[
        ["Inward No.",record.get("inward_number"),"Date",record.get("inward_date")],
        ["GRN Number",record.get("grn_number"),"Supplier Invoice",record.get("invoice_number")],
        ["Part Name",part.get("part_name") or register.get("part_name"),"Part No.",part.get("part_number") or register.get("part_number")],
        ["Supplier",supplier.get("party_name") or register.get("supplier_name"),"Heat Number",record.get("heat_number")],
        ["Heat Code",record.get("heat_code"),"RMTC Number",rmtc.get("rmtc_number") or register.get("rmtc_number")],
        ["Supplier RMTC",rmtc.get("certificate_reference") or register.get("supplier_rmtc_number"),"Input Weight kg/part",record.get("input_weight_kg")],
    ]
    story.append(_rmtc_labeled_grid(meta,[32*mm,65*mm,32*mm,65*mm],sty["label"],sty["cell"],label_columns=(0,2)))
    story.append(Spacer(1,1.5*mm)); story.append(_rmtc_section_bar("QUANTITY & STEEL ALLOCATION",content_width,sty["section"]))
    qty_rows=[
        ["Quantity", "Production pcs", "Steel kg", "Disposition / Status"],
        ["Total",record.get("production_quantity_pcs"),record.get("required_steel_quantity_kg") or record.get("steel_quantity_kg"),record.get("receipt_disposition")],
        ["Accepted",record.get("accepted_production_quantity_pcs"),record.get("accepted_steel_quantity_kg"),"ACCEPTED"],
        ["Rejected",record.get("rejected_production_quantity_pcs"),record.get("rejected_steel_quantity_kg"),"REJECTED"],
        ["On Hold",record.get("hold_production_quantity_pcs"),record.get("hold_steel_quantity_kg"),"ON_HOLD"],
    ]
    story.append(_rmtc_grid(qty_rows,[44*mm,45*mm,45*mm,60*mm],sty["header"],sty["cell"],status_columns=(3,)))
    story.append(_rmtc_section_bar("QUALITY GATE & LINKED INSPECTIONS",content_width,sty["section"]))
    quality_rows=[
        ["Quality Gate","Status","Linked Report","Report / Decision"],
        ["RMTC Validation",rmtc.get("disposition") or register.get("rmtc_disposition"),rmtc.get("rmtc_number"),rmtc.get("validation_result")],
        ["MetLAB",record.get("metallurgical_status"),metlab.get("report_number") or "-",metlab.get("disposition") or metlab.get("overall_result")],
        ["Dimensional / Final Inspection",record.get("dimensional_status"),dimensional.get("report_number") or "-",dimensional.get("disposition") or dimensional.get("overall_result")],
        ["Final Quality Decision",record.get("quality_disposition"),"Material Inward",record.get("status")],
    ]
    story.append(_rmtc_grid(quality_rows,[50*mm,42*mm,47*mm,55*mm],sty["header"],sty["cell"],status_columns=(1,3)))
    if record.get("reserve_reason") or record.get("remarks"):
        story.append(_rmtc_labeled_grid([["Hold / Reserve / Rejection Reason",record.get("reserve_reason") or "-"],["Remarks",record.get("remarks") or "-"]],[48*mm,146*mm],sty["label"],sty["cell"],label_columns=(0,)))
    story.append(Spacer(1,1.5*mm)); story.append(_rmtc_labeled_grid([["Prepared By",_employee_name(employees.get(str(record.get("prepared_by_employee_id")))),"Validated By",_employee_name(employees.get(str(record.get("validated_by_employee_id"))))]], [32*mm,65*mm,32*mm,65*mm],sty["label"],sty["center"],label_columns=(0,2)))
    doc.build(story,canvasmaker=lambda *args,**kwargs:_PageNumberCanvas(*args,report_title=title,**kwargs))
    return buffer.getvalue()


def controlled_record_pdf_bytes(
    title: str,
    header_fields: Mapping[str, object],
    sections: Mapping[str, object] | None = None,
    *,
    record_number: str = "",
    subtitle: str = "",
    images: Sequence[Mapping[str, object]] | None = None,
    images_title: str = "PHOTOGRAPHS",
) -> bytes:
    """Create a compact A4 portrait controlled-record PDF with the common QCMS header/footer.

    `sections` may contain pandas DataFrames, lists of dictionaries, dictionaries,
    or scalar values. It is intentionally reusable so every record-centric module
    can offer the same print-layout behavior without duplicating PDF code.
    """
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=8 * mm,
        rightMargin=8 * mm,
        topMargin=32 * mm,
        bottomMargin=14 * mm,
        title=title,
        author="Four Star Industries - Quality Control Monitoring System",
    )
    styles = _controlled_styles()
    content_width = A4[0] - 16 * mm
    story: list[object] = []
    if subtitle:
        sub = ParagraphStyle(
            "ControlledRecordSubtitle",
            parent=styles["cell"],
            fontSize=6.2,
            leading=7.4,
            textColor=MUTED,
            alignment=TA_CENTER,
            spaceAfter=2 * mm,
        )
        story.append(_paragraph(subtitle, sub))

    header_items = [(str(key), _display_value(value)) for key, value in header_fields.items()]
    if header_items:
        story.append(_rmtc_section_bar("RECORD DETAILS", content_width, styles["section"]))
        rows: list[list[object]] = []
        for index in range(0, len(header_items), 2):
            left = header_items[index]
            right = header_items[index + 1] if index + 1 < len(header_items) else ("", "")
            rows.append([left[0], left[1], right[0], right[1]])
        story.append(_rmtc_labeled_grid(
            rows,
            [33 * mm, 61 * mm, 33 * mm, content_width - 127 * mm],
            styles["label"],
            styles["cell"],
        ))

    for section_name, raw in (sections or {}).items():
        story.append(Spacer(1, 2.4 * mm))
        story.append(_rmtc_section_bar(section_name, content_width, styles["section"]))
        if isinstance(raw, pd.DataFrame):
            frame = raw.copy()
        elif isinstance(raw, Mapping):
            frame = pd.DataFrame([{"Field": key, "Value": value} for key, value in raw.items()])
        elif isinstance(raw, list):
            if raw and isinstance(raw[0], Mapping):
                frame = pd.DataFrame(raw)
            else:
                frame = pd.DataFrame({"Value": raw})
        elif raw is None:
            frame = pd.DataFrame()
        else:
            frame = pd.DataFrame([{"Information": raw}])
        if frame.empty:
            frame = pd.DataFrame([{"Information": "No records available."}])
        frame = frame.fillna("")
        columns = [str(column) for column in frame.columns]
        table_rows: list[list[object]] = [columns]
        table_rows.extend([list(row) for row in frame.itertuples(index=False, name=None)])
        widths = [content_width / max(1, len(columns))] * max(1, len(columns))
        status_columns = tuple(index for index, name in enumerate(columns) if "status" in name.casefold() or "result" in name.casefold())
        story.append(_rmtc_grid(table_rows, widths, styles["header"], styles["cell"], status_columns=status_columns))

    image_rows = [dict(item) for item in (images or []) if bytes(item.get("bytes") or b"")]
    if image_rows:
        story.append(Spacer(1, 2.4 * mm))
        story.append(_rmtc_section_bar(images_title, content_width, styles["section"]))
        story.append(_photo_grid_table(image_rows, content_width, styles["center"], columns=2, max_height=52 * mm))

    doc.build(
        story,
        canvasmaker=lambda *args, **kwargs: _PageNumberCanvas(
            *args,
            report_title=title,
            record_number=record_number,
            report_label=subtitle,
            **kwargs,
        ),
    )
    return buffer.getvalue()



def npd_pending_status_pdf_bytes(rows: list[Mapping[str, object]]) -> bytes:
    """A4 landscape NPD all-parts status PDF using the same process-state color scheme as the screen cards."""
    buffer = BytesIO()
    page = landscape(A4)
    doc = SimpleDocTemplate(
        buffer,
        pagesize=page,
        leftMargin=8 * mm,
        rightMargin=8 * mm,
        topMargin=32 * mm,
        bottomMargin=14 * mm,
        title="NPD Order Process Status - Pending",
        author="Four Star Industries - Quality Control Monitoring System",
    )
    styles = getSampleStyleSheet()
    summary_title = ParagraphStyle("NPDPartTitle", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=9.5, leading=11, textColor=WHITE)
    summary_name = ParagraphStyle("NPDPartName", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=6.4, leading=7.6, textColor=WHITE)
    summary_meta = ParagraphStyle("NPDPartMeta", parent=styles["Normal"], fontName="Helvetica", fontSize=5.5, leading=6.8, textColor=WHITE)
    op_style = ParagraphStyle("NPDOp", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=5.3, leading=6.2, textColor=colors.HexColor("#60788C"))
    name_style = ParagraphStyle("NPDName", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=6.2, leading=7.2, textColor=NAVY)
    status_style = ParagraphStyle("NPDStatus", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=5.5, leading=6.5)
    detail_style = ParagraphStyle("NPDDetail", parent=styles["Normal"], fontName="Helvetica", fontSize=4.8, leading=5.8, textColor=MUTED)
    legend_style = ParagraphStyle("NPDLegend", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=5.4, leading=6.5, textColor=TEXT)
    section_style = ParagraphStyle("NPDSection", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=8, leading=9.5, textColor=WHITE)

    palette = {
        "completed": (colors.HexColor("#F0FDF4"), colors.HexColor("#15803D"), "✓ Completed"),
        "completed_late": (colors.HexColor("#F8FAFC"), colors.HexColor("#6B7280"), "✓ Completed Late"),
        "in_progress": (colors.HexColor("#EFF6FF"), colors.HexColor("#2563EB"), "● In Process"),
        "pending": (colors.HexColor("#FFF7ED"), colors.HexColor("#D97706"), "○ Pending"),
        "overdue": (colors.HexColor("#FEF2F2"), colors.HexColor("#B91C1C"), "! Overdue"),
        "hold": (colors.HexColor("#F5F3FF"), colors.HexColor("#7C3AED"), "Ⅱ On Hold"),
        "not_planned": (colors.HexColor("#F8FAFC"), colors.HexColor("#64748B"), "○ Not Planned"),
    }
    content_width = page[0] - 16 * mm
    story: list[object] = []
    title_bar = Table([[Paragraph("ORDER PROCESS STATUS · ALL PENDING PARTS", section_style)]], colWidths=[content_width], rowHeights=[9 * mm])
    title_bar.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), NAVY), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 4 * mm)]))
    story.append(title_bar)
    story.append(Spacer(1, 2 * mm))
    story.append(Paragraph("Color legend:  ✓ Completed   ·   ● In Process   ·   ○ Pending   ·   ! Overdue   ·   Ⅱ On Hold", legend_style))
    story.append(Spacer(1, 2.2 * mm))

    def summary_card(row: Mapping[str, object]) -> Table:
        data = [[Paragraph(str(row.get("part_number") or "-"), summary_title)],
                [Paragraph(str(row.get("part_name") or ""), summary_name)],
                [Paragraph(f"<b>Order:</b> {_display_value(row.get('order_number'))}", summary_meta)],
                [Paragraph(f"<b>Customer:</b> {_display_value(row.get('customer'))}", summary_meta)],
                [Paragraph(f"<b>Delivery:</b> {_display_value(row.get('delivery_date'))}", summary_meta)],
                [Paragraph(f"<b>Progress:</b> {_display_value(row.get('progress'))}", summary_meta)]]
        t = Table(data, colWidths=[51 * mm], rowHeights=[7*mm, 9*mm, 5.4*mm, 6.3*mm, 5.4*mm, 5.4*mm])
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#0B5F98")),
            ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#08446F")),
            ("LEFTPADDING", (0, 0), (-1, -1), 3 * mm), ("RIGHTPADDING", (0, 0), (-1, -1), 2 * mm),
            ("TOPPADDING", (0, 0), (-1, -1), 1.2 * mm), ("BOTTOMPADDING", (0, 0), (-1, -1), 1 * mm),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]))
        return t

    def process_card(step: Mapping[str, object]) -> Table:
        state = str(step.get("state") or "not_planned")
        bg, accent, default_status = palette.get(state, palette["not_planned"])
        status = str(step.get("status") or default_status)
        stat = ParagraphStyle(f"NPDStatus_{state}", parent=status_style, textColor=accent)
        data = [
            [Paragraph(f"OP {_display_value(step.get('operation_no'))}", op_style)],
            [Paragraph(_display_value(step.get("process_name")), name_style)],
            [Paragraph(status, stat)],
            [Paragraph(f"Target {_display_value(step.get('target_date'))}", detail_style)],
            [Paragraph(_display_value(step.get("detail")), detail_style)],
        ]
        t = Table(data, colWidths=[51 * mm], rowHeights=[5*mm, 11*mm, 6*mm, 5.5*mm, 9*mm])
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), bg),
            ("BOX", (0, 0), (-1, -1), 0.65, accent),
            ("LINEBEFORE", (0, 0), (0, -1), 2.2, accent),
            ("LEFTPADDING", (0, 0), (-1, -1), 2.2 * mm), ("RIGHTPADDING", (0, 0), (-1, -1), 1.7 * mm),
            ("TOPPADDING", (0, 0), (-1, -1), 1 * mm), ("BOTTOMPADDING", (0, 0), (-1, -1), 0.7 * mm),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]))
        return t

    for index, row in enumerate(rows, start=1):
        steps = list(row.get("steps") or [])
        # Four process cards per line on A4 landscape beside the Part summary card.
        step_rows: list[list[object]] = []
        for start in range(0, len(steps), 4):
            chunk = steps[start:start + 4]
            cards = [process_card(step) for step in chunk]
            while len(cards) < 4:
                cards.append(Spacer(51 * mm, 1))
            step_rows.append(cards)
        if not step_rows:
            step_rows = [[Paragraph("No process sequence is available.", detail_style), "", "", ""]]
        process_table = Table(step_rows, colWidths=[52.5 * mm] * 4, hAlign="LEFT")
        process_table.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0.8 * mm), ("RIGHTPADDING", (0, 0), (-1, -1), 0.8 * mm), ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 1.4 * mm)]))
        row_table = Table([[summary_card(row), process_table]], colWidths=[53 * mm, content_width - 53 * mm])
        row_table.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("BACKGROUND", (0, 0), (-1, -1), WHITE),
            ("BOX", (0, 0), (-1, -1), 0.5, BORDER),
            ("LEFTPADDING", (0, 0), (-1, -1), 1.2 * mm), ("RIGHTPADDING", (0, 0), (-1, -1), 1.2 * mm),
            ("TOPPADDING", (0, 0), (-1, -1), 1.2 * mm), ("BOTTOMPADDING", (0, 0), (-1, -1), 1.2 * mm),
        ]))
        story.append(row_table)
        if index != len(rows):
            story.append(Spacer(1, 2.2 * mm))

    doc.build(story, canvasmaker=lambda *args, **kwargs: _PageNumberCanvas(*args, report_title="NPD ORDER PROCESS STATUS", report_label="Pending Part / Process Status", **kwargs))
    return buffer.getvalue()

def qc_calculation_pdf_bytes(payload: Mapping[str, object]) -> bytes:
    record = dict(payload.get("record") or {})
    employee = dict(payload.get("employee") or {})
    part = dict(payload.get("part") or {})
    grade = dict(payload.get("grade") or {})
    input_payload = dict(record.get("input_payload") or {})
    result_payload = dict(record.get("result_payload") or {})
    header = {
        "Calculation No.": record.get("calculation_number"),
        "Calculation Type": str(record.get("calculation_type") or "").replace("_", " ").title(),
        "Calculation Date": record.get("calculation_date"),
        "Performed By": _employee_name(employee),
        "Part Number": part.get("part_number"),
        "FSI Part Number": part.get("fsi_part_number"),
        "Material Grade": grade.get("grade_code"),
        "Heat Number": record.get("heat_number"),
        "Standard / Basis": record.get("standard_reference"),
        "Status": record.get("status"),
        "Remarks": record.get("remarks"),
    }
    sections: dict[str, object] = {
        "Calculation Inputs": input_payload,
    }
    calc_type = str(record.get("calculation_type") or "")
    if calc_type == "JOMINY":
        curve = result_payload.get("curve") or {}
        sections["Calculated Jominy Curve"] = pd.DataFrame([
            {"Distance (1/16 in.)": key, "Calculated HRC": value}
            for key, value in sorted(((int(k), v) for k, v in dict(curve).items()), key=lambda item: item[0])
        ])
    elif calc_type == "DI_VALUE":
        factors = result_payload.get("factors") or {}
        sections["DI Factor Details"] = pd.DataFrame([{"Factor": key, "Value": value} for key, value in dict(factors).items()])
        sections["Calculated Result"] = {"Calculated DI": result_payload.get("value"), "Error": result_payload.get("error") or ""}
    elif calc_type == "HARDNESS_CONVERSION":
        sections["Hardness Conversion Result"] = {
            "Primary Value": f"{record.get('primary_value')} {record.get('primary_unit') or ''}".strip(),
            "Converted Value": f"{record.get('result_value')} {record.get('conversion_unit') or ''}".strip(),
            "Method": result_payload.get("method"),
            "Warning": result_payload.get("warning"),
            "Interpolation Bracket": result_payload.get("bracket"),
        }
    return controlled_record_pdf_bytes(
        "QC CALCULATION RECORD",
        header,
        sections,
        record_number=str(record.get("calculation_number") or ""),
        subtitle="Stored quality calculation result",
    )
